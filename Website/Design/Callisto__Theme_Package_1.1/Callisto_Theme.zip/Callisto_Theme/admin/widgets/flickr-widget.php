<?php
/**
 * Plugin Name: Callisto Flickr Widget
 * Plugin URI: http://icarusindustries.com
 * Description: A widget that displays a Flickr stream.
 * Version: 1.0
 * Author: Icarus Industries
 * Author URI: http://icarusindustries.com
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/**
 * Add function to widgets_init that'll load our widget.
 * @since 0.1
 */
add_action( 'widgets_init', 'flickr_load_widgets' );

/**
 * Register our widget.
 * 'flickr_Widget' is the widget class used below.
 *
 * @since 0.1
 */
function flickr_load_widgets() {
	register_widget( 'flickr_Widget' );
}

/**
 * flickr Widget class.
 * This class handles everything that needs to be handled with the widget:
 * the settings, form, display, and update.  Nice!
 *
 * @since 0.1
 */
class flickr_Widget extends WP_Widget {

	/**
	 * Widget setup.
	 */
	function flickr_Widget() {
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'flickr', 'description' => __('A widget that displays a Flickr stream.', 'flickr') );

		/* Widget control settings. */
		$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'flickr-widget' );

		/* Create the widget. */
		$this->WP_Widget( 'flickr-widget', __('Callisto Flickr Stream', 'flickr'), $widget_ops, $control_ops );
	}

	/**
	 * How to display the widget on the screen.
	 */
	function widget( $args, $instance ) {
		extract( $args );

		/* Our variables from the widget settings. */
		$title = apply_filters('widget_title', $instance['title'] );
		$id = $instance['id'];
		$number = $instance['number'];

		/* Before widget (defined by themes). */
		echo $before_widget;

		/* Display the widget title if one was input (before and after defined by themes). */
		if ( $title )
			echo $before_title . $title . $after_title;
			
			echo '<script src="http://www.flickr.com/badge_code_v2.gne?count='.$number.'&amp;display=latest&amp;size=s&amp;layout=x&amp;source=user&amp;user='.$id.'"></script>';
		
		/* After widget (defined by themes). */
		echo $after_widget;
	}

	/**
	 * Update the widget settings.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['id'] = strip_tags( $new_instance['id'] );
		$instance['number'] = strip_tags( $new_instance['number'] );

		return $instance;
	}

	/**
	 * Displays the widget settings controls on the widget panel.
	 * Make use of the get_field_id() and get_field_name() function
	 * when creating your form elements. This handles the confusing stuff.
	 */
	function form( $instance ) {
	
		/* Set up some default widget settings. */
		$defaults = array( 'title' => __('Flickr', 'flickr'), 'id' => __('', 'flickr'), 'number' => __('6', 'flickr'));
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<!-- Widget Title: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'hybrid'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
		</p>
		
		<!-- Widget ID: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id( 'id' ); ?>"><?php _e('Flickr ID:', 'hybrid'); ?> (Check <a href="http://www.idgettr.com" target="_blank">idGettr</a>)</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'id' ); ?>" name="<?php echo $this->get_field_name( 'id' ); ?>" value="<?php echo $instance['id']; ?>" />
		</p>
		
		<!-- Widget Number: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e('Number of Images:', 'hybrid'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" value="<?php echo $instance['number']; ?>" />
		</p>

	<?php
	}
}
?>