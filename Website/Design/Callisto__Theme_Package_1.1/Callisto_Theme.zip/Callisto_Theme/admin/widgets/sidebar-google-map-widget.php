<?php
/**
 * Plugin Name: Callisto Sidebar Google Map Widget
 * Plugin URI: http://icarusindustries.com
 * Description: A widget that displays a Google Map in the sidebar.
 * Version: 1.0
 * Author: Icarus Industries
 * Author URI: http://icarusindustries.com
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/**
 * Add function to widgets_init that'll load our widget.
 * @since 0.1
 */
add_action( 'widgets_init', 'sidebar_gmap_load_widgets' );

/**
 * Register our widget.
 * 'sidebar_gmap_Widget' is the widget class used below.
 *
 * @since 0.1
 */
function sidebar_gmap_load_widgets() {
	register_widget( 'sidebar_gmap_Widget' );
}

/**
 * sidebar_gmap Widget class.
 * This class handles everything that needs to be handled with the widget:
 * the settings, form, display, and update.  Nice!
 *
 * @since 0.1
 */
class sidebar_gmap_Widget extends WP_Widget {

	/**
	 * Widget setup.
	 */
	function sidebar_gmap_Widget() {
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'sidebar_gmap', 'description' => __('A widget that displays a Google Map in the sidebar.', 'sidebar_gmap') );

		/* Widget control settings. */
		$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'sidebar_gmap-widget' );

		/* Create the widget. */
		$this->WP_Widget( 'sidebar_gmap-widget', __('Callisto Sidebar Google Map', 'sidebar_gmap'), $widget_ops, $control_ops );
	}

	/**
	 * How to display the widget on the screen.
	 */
	function widget( $args, $instance ) {
		extract( $args );

		/* Our variables from the widget settings. */
		$title = apply_filters('widget_title', $instance['title'] );
		$height = $instance['height'];
		$link = $instance['link'];

		/* Before widget (defined by themes). */
		echo $before_widget;

		/* Display the widget title if one was input (before and after defined by themes). */
		if ( $title )
			echo $before_title . $title . $after_title;
			
			echo '<iframe class="googleMap" width="250" height="'.$height.'" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="'.$link.'&amp;output=embed" ></iframe><script>jQuery(".googleMap").each(function(){var width=jQuery(this).parent().width()-10;jQuery(this).css("width",width)});</script>';
		
		/* After widget (defined by themes). */
		echo $after_widget;
	}

	/**
	 * Update the widget settings.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['height'] = strip_tags( $new_instance['height'] );
		$instance['link'] = strip_tags( $new_instance['link'] );

		return $instance;
	}

	/**
	 * Displays the widget settings controls on the widget panel.
	 * Make use of the get_field_id() and get_field_name() function
	 * when creating your form elements. This handles the confusing stuff.
	 */
	function form( $instance ) {
	
		/* Set up some default widget settings. */
		$defaults = array( 'title' => __('Our Location', 'sidebar_gmap'), 'height' => __('250', 'sidebar_gmap'), 'link' => __('', 'sidebar_gmap'));
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<!-- Widget Title: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'hybrid'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
		</p>
		
		<!-- Widget Height: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id( 'height' ); ?>"><?php _e('Height (in Pixels):', 'hybrid'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'height' ); ?>" name="<?php echo $this->get_field_name( 'height' ); ?>" value="<?php echo $instance['height']; ?>" />
		</p>
		
		<!-- Widget Link: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id( 'link' ); ?>"><?php _e('Google Maps Link:', 'hybrid'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link' ); ?>" name="<?php echo $this->get_field_name( 'link' ); ?>" value="<?php echo $instance['link']; ?>" />
		</p>

	<?php
	}
}
?>