(function(){
	tinymce.create('tinymce.plugins.quicktags', {
		/**
		 * Initializes the plugin, this will be executed after the plugin has been created.
		 * This call is done before the editor instance has finished it's initialization so use the onInit event
		 * of the editor instance to intercept that event.
		 *
		 * @param {tinymce.Editor} ed Editor instance that the plugin is initialized in.
		 * @param {string} url Absolute URL to where the plugin is located.
		 */
		init : function(ed, url) {
		
			page_divideHTML = '<img src="' + url + '/img/trans.gif" class="mceWPmore mceItemNoResize" title="'+ed.getLang('wordpress.wp_more_alt')+'" />';		
		
			ed.addButton('alert_box', {
				title : 'Add Alert Box',
				image : url + '/../images/alertBox.png',
				onclick : function() {
					shortcodeEnact('alert_box');
				}
			});
			ed.addButton('add_button', {
				title : 'Add Button',
				image : url + '/../images/button.png',
				onclick : function() {
					shortcodeEnact('add_button');
				}
			});
			ed.addButton('tabs', {
				title : 'Add Tabs',
				image : url + '/../images/tab.png',
				onclick : function() {
					shortcodeEnact('tabs');
				}
			});
			ed.addButton('toggle', {
				title : 'Add Toggle',
				image : url + '/../images/toggle.png',
				onclick : function() {
					shortcodeEnact('toggle');
				}
			});
			ed.addButton('quote', {
				title : 'Add Quote',
				image : url + '/../images/blockquote.png',
				onclick : function() {
					shortcodeEnact('quote');
				}
			});
			ed.addButton('slider', {
				title : 'Add Slider',
				image : url + '/../images/slider.png',
				onclick : function() {
					shortcodeEnact('slider');
				}
			});
			ed.addButton('youtube', {
				title : 'Add Youtube Video',
				image : url + '/../images/youtube.png',
				onclick : function() {
					shortcodeEnact('youtube');
				}
			});
			ed.addButton('vimeo', {
				title : 'Add Vimeo Video',
				image : url + '/../images/vimeo.png',
				onclick : function() {
					shortcodeEnact('vimeo');
				}
			});
			ed.addButton('google_map', {
                title : 'Google Map',
                image : url+'/../images/map.png',
                onclick : function() {
                     shortcodeEnact('google_map');
                }
            });
            ed.addButton('page_full', {
                title : 'Full Width Page',
                image : url+'/../images/pageFull.png',
                onclick : function() {
                     ed.selection.setContent('<div class="pageBlock"><div class="pageTop"><!-- pageTop --></div><div class="pageMiddle group"><p>Page - Full</p></div><div class="pageBottom"><!-- pageBottom --></div><div class="pageShadow"><!-- pageShadow --></div></div><!-- end of page -->\n');
                }
            });
            ed.addButton('page_two_thirds', {
	            title : 'Two Thirds Page',
	            image : url+'/../images/pageTwoThirds.png',
	            onclick : function() {
                     ed.selection.setContent('<div class="pageBlock boxTwoThirds"><div class="pageTop"><!-- pageTop --></div><div class="pageMiddle group"><p>Page - Two Thirds</p></div><div class="pageBottom"><!-- pageBottom --></div><div class="pageShadow"><!-- pageShadow --></div></div><!-- end of page -->\n');
	
	            }
	        });
            ed.addButton('page_one_half', {
                title : 'One Half Page',
                image : url+'/../images/pageOneHalf.png',
                onclick : function() {
                     ed.selection.setContent('<div class="pageBlock boxOneHalf"><div class="pageTop"><!-- pageTop --></div><div class="pageMiddle group"><p>Page - One Half</p></div><div class="pageBottom"><!-- pageBottom --></div><div class="pageShadow"><!-- pageShadow --></div></div><!-- end of page -->\n');
    
                }
            });
	        ed.addButton('page_one_third', {
	            title : 'One Third Page',
	            image : url+'/../images/pageOneThird.png',
	            onclick : function() {
                     ed.selection.setContent('<div class="pageBlock boxOneThird"><div class="pageTop"><!-- pageTop --></div><div class="pageMiddle group"><p>Page - One Third</p></div><div class="pageBottom"><!-- pageBottom --></div><div class="pageShadow"><!-- pageShadow --></div></div><!-- end of page -->\n');
	            }
	        });
            ed.addButton('col_two_thirds', {
                title : 'Two Thirds, One Third',
                image : url+'/../images/colTwoThirds.png',
                onclick : function() {
                     ed.selection.setContent('<div class="pageInner group"><div class="twoThirds group"><p>Column - Two Thirds</p></div><div class="oneThird group"><p>Column - Third</p></div></div><!-- end of column row -->\n');
    
                }
            });
            ed.addButton('col_two_thirds_alt', {
                title : 'One Third, Two Thirds',
                image : url+'/../images/colTwoThirdsAlt.png',
                onclick : function() {
                     ed.selection.setContent('<div class="pageInner group"><div class="oneThird group"><p>Column - Third</p></div><div class="twoThirds group"><p>Column - Two Thirds</p></div></div><!-- end of column row -->\n');
    
                }
            });
            ed.addButton('col_one_half', {
                title : 'One Half, One Half',
                image : url+'/../images/colOneHalf.png',
                onclick : function() {
                     ed.selection.setContent('<div class="pageInner group"><div class="oneHalf group"><p>Column - Half</p></div><div class="oneHalf group"><p>Column - Half</p></div></div><!-- end of column row -->\n');
    
                }
            });
            ed.addButton('col_one_third', {
                title : 'One Third, One Third, One Third',
                image : url+'/../images/colOneThird.png',
                onclick : function() {
                     ed.selection.setContent('<div class="pageInner group"><div class="oneThird group"><p>Column - Third</p></div><div class="oneThird group"><p>Column - Third</p></div><div class="oneThird group"><p>Column - Third</p></div></div><!-- end of column row -->\n');
    
                }
            });
            ed.addButton('col_three_fourths', {
                title : 'Three Fourths, One Fourth',
                image : url+'/../images/colThreeFourths.png',
                onclick : function() {
                     ed.selection.setContent('<div class="pageInner group"><div class="threeFourths group"><p>Column - Three Fourths</p></div><div class="oneFourth group"><p>Column - Fourth</p></div></div><!-- end of column row -->\n');
    
                }
            });
            ed.addButton('col_three_fourths_alt', {
                title : 'One Fourth, Three Fourths',
                image : url+'/../images/colThreeFourthsAlt.png',
                onclick : function() {
                     ed.selection.setContent('<div class="pageInner group"><div class="oneFourth group"><p>Column - Fourth</p></div><div class="threeFourths group"><p>Column - Three Fourths</p></div></div><!-- end of column row -->\n');
    
                }
            });
            ed.addButton('col_half_two_fourths', {
                title : 'One Half, Two Fourths',
                image : url+'/../images/colHalfTwoFourths.png',
                onclick : function() {
                     ed.selection.setContent('<div class="pageInner group"><div class="oneHalf group"><p>Column - Half</p></div><div class="oneFourth group"><p>Column - Fourth</p></div><div class="oneFourth group"><p>Column - Fourth</p></div></div><!-- end of column row -->\n');
    
                }
            });
            ed.addButton('col_half_two_fourths_alt', {
                title : 'Two Fourths, One Half',
                image : url+'/../images/colHalfTwoFourthsAlt.png',
                onclick : function() {
                     ed.selection.setContent('<div class="pageInner group"><div class="oneFourth group"><p>Column - Fourth</p></div><div class="oneFourth group"><p>Column - Fourth</p></div><div class="oneHalf group"><p>Column - Half</p></div></div><!-- end of column row -->\n');
    
                }
            });
            ed.addButton('col_one_fourth', {
                title : 'One Fourth, One Fourth, One Fourth, One Fourth',
                image : url+'/../images/colOneFourth.png',
                onclick : function() {
                     ed.selection.setContent('<div class="pageInner group"><div class="oneFourth group"><p>Column - Fourth</p></div><div class="oneFourth group"><p>Column - Fourth</p></div><div class="oneFourth group"><p>Column - Fourth</p></div><div class="oneFourth group"><p>Column - Fourth</p></div></div><!-- end of column row -->\n');
    
                }
            });
            ed.addButton('page_divider', {
                title : 'Page Divider',
                image : url+'/../images/pageDivider.png',
                onclick : function() {
                     ed.selection.setContent('<div class="pageDivider"><a href="#top">Top &uarr;</a></div>\n');
    
                }
            });
            ed.addButton('contact_form', {
                title : 'Add Contact Form',
                image : url+'/../images/contact.png',
                onclick : function() {
                     ed.selection.setContent('[contact_form]');
    
                }
            });
            ed.addButton('subtitle_space', {
                title : 'Subtitle Space',
                image : url+'/../images/subtitle.png',
                onclick : function() {
                     ed.selection.setContent('[subtitle_space]Subtitle[/subtitle_space]\n');
    
                }
            });
	        ed.addButton('h1', {
	            title : 'Heading Level 1',
	            image : url+'/../images/h1.png',
	            onclick : function() {
                     ed.selection.setContent('<h1>Heading</h1>\n');
	
	            }
	        });
	        ed.addButton('h2', {
	            title : 'Heading Level 2',
	            image : url+'/../images/h2.png',
	            onclick : function() {
                     ed.selection.setContent('<h2>Heading</h2>\n');
	
	            }
	        });
	        ed.addButton('h3', {
                title : 'Heading Level 3',
                image : url+'/../images/h3.png',
                onclick : function() {
                     ed.selection.setContent('<h3>Heading</h3>\n');
    
                }
            });
            ed.addButton('h4', {
                title : 'Heading Level 4',
                image : url+'/../images/h4.png',
                onclick : function() {
                     ed.selection.setContent('<h4>Heading</h4>\n');
    
                }
            });
            ed.addButton('h5', {
                title : 'Heading Level 5',
                image : url+'/../images/h5.png',
                onclick : function() {
                     ed.selection.setContent('<h5>Heading</h5>\n');
    
                }
            });
            ed.addButton('h6', {
                title : 'Heading Level 6',
                image : url+'/../images/h6.png',
                onclick : function() {
                     ed.selection.setContent('<h6>Heading</h6>\n');
    
                }
            });
            ed.addButton('pre_pretty', {
                title : 'Add pre',
                image : url+'/../images/pre.png',
                onclick : function() {
                     ed.selection.setContent('<pre class="prettyprint"><code>[pre_pretty]Content[/pre_pretty]</code></pre>\n');
                }
            });
            ed.addButton('code_pretty', {
                title : 'Add code',
                image : url+'/../images/code.png',
                onclick : function() {
                     ed.selection.setContent('<code class="prettyprint">[code_pretty]Content[/code_pretty]</code>\n');
                }
            });
            ed.addButton('dropcap', {
	            title : 'Dropcap Letter Highlight',
	            image : url+'/../images/dropcap.png',
	            onclick : function() {
	            	shortcodeEnact('dropcap');
	            }
	        });
		},
		/**
		 * Creates control instances based in the incoming name. This method is normally not
		 * needed since the addButton method of the tinymce.Editor class is a more easy way of adding buttons
		 * but you sometimes need to create more complex controls like listboxes, split buttons etc then this
		 * method can be used to create those.
		 *
		 * @param {String} n Name of the control to create.
		 * @param {tinymce.ControlManager} cm Control manager to use inorder to create new control.
		 * @return {tinymce.ui.Control} New control instance or null if no control was created.
		 */
		createControl : function(n, cm) {
			return null;
		},

		/**
		 * Returns information about the plugin as a name/value array.
		 * The current keys are longname, author, authorurl, infourl and version.
		 *
		 * @return {Object} Name/value array containing information about the plugin.
		 */
		getInfo : function() {
			return {
				longname : "Shortcodes for the Callisto WP Theme",
				author : 'Icarus Industries',
				authorurl : 'http://icarusindustries.com/',
				infourl : 'http://icarusindustries.com/',
				version : "1.0"
			};
		}
	});
	
	tinymce.PluginManager.add('quicktags', tinymce.plugins.quicktags);
})()