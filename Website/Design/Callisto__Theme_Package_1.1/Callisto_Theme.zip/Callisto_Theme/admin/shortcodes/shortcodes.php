<?php 

function shortcode_admin_css() {
	echo '<style type="text/css">
			.mceButton, .mceButton img {
				cursor: pointer!important;
			}
			#content_col_full, #content_col_full img, #content_col_one_fourth, #content_col_one_fourth img, #content_col_container, #content_col_container img, #content_toggle, #content_toggle img {
				width: 21px;
			}
			#content_col_two_thirds, #content_col_two_thirds img, #content_col_three_fourths, #content_col_three_fourths img, #content_col_one_half, #content_col_one_half img  {
				width: 19px;
			}
			#content_subtitle_space, #content_subtitle_space img, #content_pre_pretty, #content_pre_pretty img {
				width: 40px;
			}
			#content_code_pretty, #content_code_pretty img {
				width: 53px;
			}
	</style>';
}
add_action('admin_head', 'shortcode_admin_css');


/*-----------------------------------------------------------------------------------*/
/* Page Sizes
/*-----------------------------------------------------------------------------------*/

function page_full( $atts, $content = null ) {
	$content = content_helper($content);
	return '<div class="pageBlock"><span class="pageTop"></span><div class="pageMiddle group">'.do_shortcode($content).'</div><span class="pageBottom"></span><span class="pageShadow"></span></div>';
}
add_shortcode('page_full', 'page_full');

function page_one_half( $atts, $content = null ) {
	$content = content_helper($content);
	return '<div class="pageBlock boxOneHalf"><span class="pageTop"></span><div class="pageMiddle group">'.do_shortcode($content).'</div><span class="pageBottom"></span><span class="pageShadow"></span></div>';
}
add_shortcode('page_one_half', 'page_one_half');

function page_two_thirds( $atts, $content = null ) {
	$content = content_helper($content);
	return '<div class="pageBlock boxTwoThirds"><span class="pageTop"></span><div class="pageMiddle group">'.do_shortcode($content).'</div><span class="pageBottom"></span><span class="pageShadow"></span></div>';
}
add_shortcode('page_two_thirds', 'page_two_thirds');

function page_one_third( $atts, $content = null ) {
	$content = content_helper($content);
	return '<div class="pageBlock boxOneThird"><span class="pageTop"></span><div class="pageMiddle group">'.do_shortcode($content).'</div><span class="pageBottom"></span><span class="pageShadow"></span></div>';
}
add_shortcode('page_one_third', 'page_one_third');


/*-----------------------------------------------------------------------------------*/
/* Column Sizes
/*-----------------------------------------------------------------------------------*/

function col_container( $atts, $content = null ) {
	$content = content_helper($content);
	return '<div class="pageInner group">'.do_shortcode($content).'</div>';
}
add_shortcode('col_container', 'col_container');

function col_full( $atts, $content = null ) {
	$content = content_helper($content);
	return '<div class="full group">'.do_shortcode($content).'</div>';
}
add_shortcode('col_full', 'col_full');

function col_one_half( $atts, $content = null ) {
	$content = content_helper($content);
	return '<div class="oneHalf group">'.do_shortcode($content).'</div>';
}
add_shortcode('col_one_half', 'col_one_half');

function col_two_thirds( $atts, $content = null ) {
	$content = content_helper($content);
	return '<div class="twoThirds group">'.do_shortcode($content).'</div>';
}
add_shortcode('col_two_thirds', 'col_two_thirds');

function col_one_third( $atts, $content = null ) {
	$content = content_helper($content);
	return '<div class="oneThird group">'.do_shortcode($content).'</div>';
}
add_shortcode('col_one_third', 'col_one_third');

function col_three_fourths( $atts, $content = null ) {
	$content = content_helper($content);
	return '<div class="threeFourths group">'.do_shortcode($content).'</div>';
}
add_shortcode('col_three_fourths', 'col_three_fourths');

function col_one_fourth( $atts, $content = null ) {
	$content = content_helper($content);
	return '<div class="oneFourth group">'.do_shortcode($content).'</div>';
}
add_shortcode('col_one_fourth', 'col_one_fourth');


/*-----------------------------------------------------------------------------------*/
/* Typography
/*-----------------------------------------------------------------------------------*/

function subtitle_space( $atts, $content = null ) {
	$content = content_helper($content);
	return '</div></div><div class="subtitleSpace"><div class="container group"><h2>'.$content.'</h2></div></div><div class="container group"><div class="containerInner group">';
}
add_shortcode('subtitle_space', 'subtitle_space');

function h1( $atts, $content = null ) {
	$content = content_helper($content);
	return '<h1>'.$content.'</h1>';
}
add_shortcode('h1', 'h1');

function h2( $atts, $content = null ) {
	$content = content_helper($content);
	return '<h2>'.$content.'</h2>';
}
add_shortcode('h2', 'h2');

function h3( $atts, $content = null ) {
	$content = content_helper($content);
	return '<h3>'.$content.'</h3>';
}
add_shortcode('h3', 'h3');

function h4( $atts, $content = null ) {
	$content = content_helper($content);
	return '<h4>'.$content.'</h4>';
}
add_shortcode('h4', 'h4');

function h5( $atts, $content = null ) {
	$content = content_helper($content);
	return '<h5>'.$content.'</h5>';
}
add_shortcode('h5', 'h5');

function h6( $atts, $content = null ) {
	$content = content_helper($content);
	return '<h6>'.$content.'</h6>';
}
add_shortcode('h6', 'h6');

function quote( $atts, $content = null ) {
	extract(shortcode_atts(array(
				"align" => "",
				"cite" => ""
			), $atts));
	$content = content_helper($content);
		
	if ($cite == '') {
		$output .= '<blockquote class="'.$align.'">'.$content.'</blockquote>';
	} else {
		$output .= '<blockquote class="'.$align.'">'.$content.'<cite> - '.$cite.'</cite></blockquote>';
	}
	
	return $output;
}
add_shortcode('quote', 'quote');

function dropcap( $atts, $content = null ) {
	extract(shortcode_atts(array(
				"type" => "Dark on Light"
			), $atts));
	$content = content_helper($content);
	
	if ($type == 'Dark on Light') 
		$output .= '<span class="dropcap1">'.$content.'</span>';
	
	if ($type == 'Light on Dark') 
		$output .= '<span class="dropcap2">'.$content.'</span>';
		
	return $output;
}
add_shortcode('dropcap', 'dropcap');


/*-----------------------------------------------------------------------------------*/
/* Custom Elements
/*-----------------------------------------------------------------------------------*/

function masonry( $atts, $content = null ) {
	$content = content_helper($content);
	return '<div class="masonry group">'.$content.'</div>';
}
add_shortcode('masonry', 'masonry');

function page_divider( $atts, $content = null ) {
	return '<div class="pageDivider"><a href="#top">Top &uarr;</a></div>';
}
add_shortcode('page_divider', 'page_divider');

function youtube( $atts, $content = null ) {
	extract(shortcode_atts(array(
				"clip" => ""
			), $atts));
	$content = content_helper($content);

	return '<iframe title="YouTube video player" class="youtube" src="http://www.youtube.com/embed/'.$clip.'?rel=0&amp;hd=1" frameborder="0" allowfullscreen></iframe><script>jQuery(".youtube").each(function(){var width=jQuery(this).parent().width()-10;var height=(width*.5625)+30;jQuery(this).css({"width":width,"height":height})});jQuery(".tab_content .youtube").each(function(){var width=jQuery(this).parent().parent().width()-10;var height=(width*.5625)+30;jQuery(this).css({"width":width,"height":height})});</script>';
}
add_shortcode('youtube', 'youtube');

function vimeo( $atts, $content = null ) {
	extract(shortcode_atts(array(
				"clip" => ""
			), $atts));
	$content = content_helper($content);

	return '<iframe title="Vimeo video player" class="vimeo" src="http://player.vimeo.com/video/'.$clip.'" frameborder="0"></iframe><script>jQuery(".vimeo").each(function(){var width=jQuery(this).parent().width()-10;var height=width*.5625;jQuery(this).css({"width":width,"height":height})});jQuery(".tab_content .vimeo").each(function(){var width=jQuery(this).parent().parent().width()-10;var height=width*.5625;jQuery(this).css({"width":width,"height":height})});</script>';
}
add_shortcode('vimeo', 'vimeo');

function pre_pretty( $atts, $content = null ) {
	return $content;
}
add_shortcode('pre_pretty', 'pre_pretty');

function code_pretty( $atts, $content = null ) {
	return $content;
}
add_shortcode('code_pretty', 'code_pretty');

function lightbox( $atts, $content = null ) {
	extract(shortcode_atts(array(
				"link" => "",
				"title" => "",
				"set" => ""
			), $atts));
	$content = content_helper($content);
	
	if ($set == "") {
		$output .= '<a title="'.$title.'" rel="lightbox" class="lightbox" href="'.$link.'">'.$content.'</a>';
	}	
	else {
		$output .= '<a title="'.$title.'" rel="lightbox['.$set.']" class="lightbox" href="'.$link.'">'.$content.'</a>';
	}
	return $output;
}
add_shortcode('lightbox', 'lightbox');

function slider( $atts, $content = null ) {
	extract(shortcode_atts(array(
				"width" => "",
				"height" => "",
				"align" => ""
			), $atts));
	$content = content_helper($content);

	return '<div class="sliderHolder preloadHolder group '.$align.'" style="width:'.$width.'px; height:'.$height.'px;"><div class="nivoSlider preloadMe sliderEmbed group" style="width:'.$width.'px; height:'.$height.'px;">'.$content.'</div></div>';
}
add_shortcode('slider', 'slider');

function image( $atts, $content = null ) {
	extract(shortcode_atts(array(
				"width" => "",
				"height" => "",
				"link" => "",
				"caption" => ""
			), $atts));
			
	global $blog_id;
	
	if (is_multisite()) {
		$output .= '<img alt="" src="'.get_bloginfo("template_directory").'/admin/timthumb.php?src='.get_current_site(1)->path.str_replace(get_blog_option($blog_id,'fileupload_url'),get_blog_option($blog_id,'upload_path'),$link).'&h='.$height.'&w='.$width.'" title="'.$caption.'" />';
	} else {
		$output .= '<img alt="" src="'.get_bloginfo("template_directory").'/admin/timthumb.php?src='.$link.'&h='.$height.'&w='.$width.'" title="'.$caption.'" />';
	}
	
	return $output;
}
add_shortcode('image', 'image');

function contact_form( $atts, $content = null ) {
	ob_start();
	$output = include(TEMPLATEPATH . '/includes/contact-form.php');
	$output = ob_get_clean();
	return $output;
}
add_shortcode('contact_form', 'contact_form');

add_shortcode('alert_box', 'alert_box');
function alert_box($atts, $content = null) {
	extract(shortcode_atts(array(
				"type" => "Info",
				"icon" => "Yes"
			), $atts));
	$content = content_helper($content);
	
	if ($icon == 'Yes' || $icon == '') {
		$icon = '';
	} else {
		$icon = ' noIcon';
	}
	
	if ($type == 'Info')
		$output .= '<div class="alertBox blue group'.$icon.'"><div class="group">'.$content.'</div></div>';
	
	if ($type == 'Success') 
		$output .= '<div class="alertBox green group'.$icon.'"><div class="group">'.$content.'</div></div>';
	
	if ($type == 'General') 
		$output .= '<div class="alertBox yellow group'.$icon.'"><div class="group">'.$content.'</div></div>';
	
	if ($type == 'Error')
		$output .= '<div class="alertBox red group'.$icon.'"><div class="group">'.$content.'</div></div>';
		
	return $output;
}

add_shortcode('add_button', 'add_button');
function add_button($atts, $content = null) {
	extract(shortcode_atts(array(
				"link" => "#",
				"colour" => "blue",
				"position" => "Float left"
	), $atts));
	
	$content = content_helper($content);
	
	if ($position == 'Float left')
		$output .= "<a href='{$link}' class='button alignleft {$colour}'><div><p>{$content}</p></div></a>";
		
	if ($position == 'Float right')
		$output .= "<a href='{$link}' class='button alignright {$colour}'><div><p>{$content}</p></div></a>";
		
	if ($position == 'Full width')
		$output .= "<a href='{$link}' class='button width100 {$colour}'><div><p>{$content}</p></div></a>";
		
	return $output;
}

add_shortcode('tabs', 'tabs');
function tabs($atts, $content = null) {
	$output = null;
	extract(shortcode_atts(array(
				"position" => "Left"
			), $atts));
			
	$content = content_helper($content);
		
	if ($position == 'Left')
		$output .= "
			<div class='tabbedContent tabsLeft group'>
				{$content}
			<script>jQuery('.tabsLeft').each(function(){var tabWidth=Math.floor(jQuery('li',this).width()-3);jQuery('ul.tabs li a',this).css('width',tabWidth);jQuery(this).find('ul.tabs li:first').addClass('active')});</script></div>";
		
	if ($position == 'Top')
		$output .= "
			<div class='tabbedContent tabsTop group'>
				{$content}
			<script>jQuery('.tabsTop').each(function(){var n=jQuery('ul.tabs li',this).length;var tabWidth=Math.floor((jQuery(this).width()-(21*(n-1)))/n);jQuery('ul.tabs li',this).css('width',tabWidth);jQuery('ul.tabs li a',this).css('width',(tabWidth-2));jQuery(this).find('ul.tabs li:first').addClass('active')});</script></div>";
			
	return $output;
}

add_shortcode('tabcontainer', 'tabcontainer');
function tabcontainer($atts, $content = null) {
	$content = content_helper($content);
	
	$output = "
		<ul class='tabs group'>
			{$content}
		</ul> <!-- /.tabs -->";
		
	return $output;
}

function tabHeader() {
    static $a = 0;
    $a++;
    return 'tab' . $a;
}

add_shortcode('tabtext', 'tabtext');
function tabtext($atts, $content = null) {	

	$content = content_helper($content);
			
	return "
		<li>
			<a href='#".tabHeader()."' class='button'>
				<div>
					<p>{$content}</p>
				</div>
			</a>
		</li>";
}

function tabMatcher() {
    static $a = 0;
    $a++;
    return 'tab' . $a;
}

add_shortcode('tab', 'tab');
function tab($atts, $content = null) {
	
	$content = content_helper($content);
	
	return "
		<div id='".tabMatcher()."' class='tab_content group'>
			{$content}
		</div>";
}

add_shortcode('tabcontent', 'tabcontent');
function tabcontent($atts, $content = null) {
	
	$content = content_helper($content);

	$output = "
		<div class='tab_container'>
			{$content}
		</div>";
	
	return $output;
}

add_shortcode('toggle', 'toggle');
function toggle($atts, $content = null) {
	extract(shortcode_atts(array(
				"title" => ""
	), $atts));
			
	$content = content_helper($content);
			
	return "
		<h3 class='trigger'><a href='#'>{$title}</a></h3>
		<div class='toggle_container group'>
			<div class='block group'>
				{$content}
			</div> <!-- /.block -->
		</div> <!-- /.toggle_container -->";
}

function google_map($atts, $content = null) {
   extract(shortcode_atts(array(
      "height" => '320',
      "src" => ''
   ), $atts));
   return '<iframe class="googleMap" height="'.$height.'" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="'.$src.'&amp;output=embed" ></iframe><script>jQuery(".googleMap").each(function(){var width=jQuery(this).parent().width()-10;jQuery(this).css("width",width)});</script>';
}
add_shortcode("google_map", "google_map");


/*-----------------------------------------------------------------------------------*/
/* Functions
/*-----------------------------------------------------------------------------------*/

function delete_htmltags($content,$paragraph_tag=false,$br_tag=false){	
	$content = preg_replace('#^<\/p>|^<br \/>|<p>$#', '', $content);
	
	$content = preg_replace('#<br \/>#', '', $content);
	
	if ( $paragraph_tag ) $content = preg_replace('#<p>|</p>#', '', $content);
		
	return trim($content);
}

function content_helper($content,$paragraph_tag=false,$br_tag=false){
	return delete_htmltags( do_shortcode(shortcode_unautop($content)), $paragraph_tag, $br_tag );
}

add_action('admin_init', 'action_admin_init');
function action_admin_init(){
	if ( current_user_can( 'edit_posts' ) && current_user_can( 'edit_pages' ) ) {
		if ( in_array(basename($_SERVER['PHP_SELF']), array('post-new.php', 'page-new.php', 'post.php', 'page.php') ) ) {
			add_filter('mce_buttons', 'filter_mce_button');
			add_filter('mce_buttons_3', 'register_button_line2');
			add_filter('mce_buttons_4', 'register_button_line3');
			add_filter('mce_external_plugins', 'filter_mce_plugin');
			add_action('edit_form_advanced', 'advanced_buttons');
			add_action('edit_page_form', 'advanced_buttons');
		}
	}
}

function filter_mce_button($buttons) {
	array_push( $buttons, '|', 'alert_box', 'add_button', 'tabs', 'toggle', 'slider', 'google_map' );
	return $buttons;
}

function register_button_line2($buttons) {
	array_push($buttons, 'page_full', 'page_one_half', 'page_two_thirds', 'page_one_third', '|', 'col_one_half', 'col_two_thirds', 'col_two_thirds_alt', 'col_one_third', 'col_three_fourths', 'col_three_fourths_alt', 'col_half_two_fourths', 'col_half_two_fourths_alt', 'col_one_fourth', '|', 'page_divider', 'contact_form');
	return $buttons;
}

function register_button_line3($buttons) {
	array_push($buttons, 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', '|', 'subtitle_space', 'quote', 'dropcap', 'pre_pretty', 'code_pretty', '|',  'youtube', 'vimeo');
	return $buttons;
}

function filter_mce_plugin($plugins) {	
	$plugins['quicktags'] = get_template_directory_uri(). '/admin/shortcodes/js/editor_plugin.js';
	return $plugins;
}


/*-----------------------------------------------------------------------------------*/
/* Advanced Buttons
/*-----------------------------------------------------------------------------------*/

function advanced_buttons(){ ?>
	<script type="text/javascript">
		var defaultSettings = {},
			outputOptions = '',
			selected ='',
			content = '';
		
		defaultSettings['alert_box'] = {
			type: {
				name: 'Type',
				defaultvalue: 'Info',
				description: 'Type of box',
				type: 'select',
				options: 'Info|Success|General|Error'
			},
			icon: {
				name: 'Show Icon?',
				defaultvalue: 'Yes',
				description: 'Should a relevant icon be displayed inside the alert box?',
				type: 'select',
				options: 'Yes|No'
			},
			content: {
				name: 'Content',
				defaultvalue: '',
				description: 'Text or HTML',
				type: 'textarea'
			}
		};
		
		defaultSettings['dropcap'] = {
			type: {
				name: 'Type',
				defaultvalue: 'Dark on Light',
				description: 'Choose style',
				type: 'select',
				options: 'Dark on Light|Light on Dark'
			},
			content: {
				name: 'Highlighted Character',
				defaultvalue: '',
				description: 'Letter/Number/Symbol',
				type: 'text'
			}
		};
		
		defaultSettings['add_button'] = {
			colour: {
				name: 'Colour',
				defaultvalue: 'blue',
				description: 'Button colour',
				type: 'select',
				options: 'blue|green|yellow|red'
			},
			position: {
				name: 'Position',
				defaultvalue: '',
				description: 'Float left',
				type: 'select',
				options: 'Float left|Float right|Full width'
			},
			content: {
				name: 'Button Text',
				defaultvalue: '',
				description: 'Text',
				type: 'text'
			},
			link: {
				name: 'Link',
				defaultvalue: 'http://',
				description: 'URL',
				type: 'text'
			}
		};
		
		defaultSettings['tabs'] = {
			position: {
				name: 'Position',
				defaultvalue: 'Left',
				description: 'Where should the tabs be placed?',
				type: 'select',
				options: 'Left|Top'
			},
			tabtext: {
				name: 'Tab Text',
				defaultvalue: '',
				description: '',
				type: 'text',
				clone: 'cloned'
			},
			tabcontent: {
				name: 'Tab Content',
				defaultvalue: '',
				description: 'Text/HTML',
				type: 'textarea',
				clone: 'cloned'
			}
		};
		
		defaultSettings['slider'] = {
			align: {
				name: 'Align',
				defaultvalue: 'Center',
				description: 'How should the slider be aligned on the page?',
				type: 'select',
				options: 'Center|Left|Right'
			},
			width: {
				name: 'Width',
				defaultvalue: '',
				description: 'Enter the width of the slider. All images will be resized to this width.',
				type: 'text',
			},
			height: {
				name: 'Height',
				defaultvalue: '',
				description: 'Enter the height of the slider. All images will be resized to this height.',
				type: 'text',
			},
			imgLink: {
				name: 'Image Link',
				defaultvalue: '',
				description: 'Enter the URL of the image',
				type: 'text',
				clone: 'cloned'
			},
			imgCaption: {
				name: 'Image Caption',
				defaultvalue: '',
				description: 'Enter a caption for the image',
				type: 'text',
				clone: 'cloned'
			}
		};
		
		defaultSettings['toggle'] = {
			title: {
				name: 'Toggle Title',
				defaultvalue: '',
				description: 'Toggle heading',
				type: 'text'
			},
			content: {
				name: 'Toggle Content',
				defaultvalue: '',
				description: 'Text/HTML',
				type: 'textarea'
			}
		};
		
		defaultSettings['quote'] = {
			align: {
				name: 'Align',
				defaultvalue: 'Full',
				description: 'The alignment of the quote.',
				type: 'select',
				options: 'Full|Left|Right'
			},
			content: {
				name: 'Quote',
				defaultvalue: '',
				description: 'Enter your quotation. This will be output as a blockquote.',
				type: 'textarea'
			},
			cite: {
				name: 'Citation',
				defaultvalue: '',
				description: 'A name/source/year for the quote. Can be left blank.',
				type: 'text'
			}
		};
		
		defaultSettings['youtube'] = {
			clip: {
				name: 'What is the clip ID?',
				defaultvalue: '',
				description: 'A string of letters/numbers typically attached to the URL.',
				type: 'text'
			}
		};
		
		defaultSettings['vimeo'] = {
			clip: {
				name: 'What is the clip ID?',
				defaultvalue: '',
				description: 'A string of numbers typically attached to the URL.',
				type: 'text'
			}
		};
		
		defaultSettings['google_map'] = {
			src: {
				name: 'What is the Google Map link?',
				defaultvalue: '',
				description: 'Please see theme documentation for details.',
				type: 'text'
			},
			height: {
				name: 'Google Map height (in px)',
				defaultvalue: '',
				description: 'Enter the height for the Google Map',
				type: 'text'
			}
		};
		
		function shortcodeEnact(tag){
			
			var index = tag;
			
				for (var index2 in defaultSettings[index]) {
					if (defaultSettings[index][index2]['clone'] === 'cloned')
						outputOptions += '<tr class="cloned">\n';
					else if (index === 'button' && index2 === 'icon')
						outputOptions += '<tr class="hidden">\n';
					else
						outputOptions += '<tr>\n';
					outputOptions += '<th><label for="' + index2 + '">'+ defaultSettings[index][index2]['name'] +'</label></th>\n';
					outputOptions += '<td>';
					
					if (defaultSettings[index][index2]['type'] === 'select') {
						var optionsArray = defaultSettings[index][index2]['options'].split('|');
						
						outputOptions += '\n<select name="'+index2+'" id="'+index2+'">\n';
						
						for (var index3 in optionsArray) {
							selected = (optionsArray[index3] === defaultSettings[index][index2]['defaultvalue']) ? ' selected="selected"' : '';
							outputOptions += '<option value="'+optionsArray[index3]+'"'+ selected +'>'+optionsArray[index3]+'</option>\n';
						}
						
						outputOptions += '</select>\n';
					}
					
					if (defaultSettings[index][index2]['type'] === 'text') {
						cloned = '';
						if (defaultSettings[index][index2]['clone'] === 'cloned') cloned = "[]";
						outputOptions += '\n<input type="text" name="'+index2+cloned+'" id="'+index2+'" value="'+defaultSettings[index][index2]['defaultvalue']+'" />\n';
					}
					
					if (defaultSettings[index][index2]['type'] === 'textarea') {
						cloned = '';
						if (defaultSettings[index][index2]['clone'] === 'cloned') cloned = "[]";
						outputOptions += '<textarea name="'+index2+cloned+'" id="'+index2+'" cols="40" rows="10">'+defaultSettings[index][index2]['defaultvalue']+'</textarea>';
					}
					
					outputOptions += '\n<br/><small>'+ defaultSettings[index][index2]['description'] +'</small>';
					outputOptions += '\n</td>';
					
				}
			
		
			var width = jQuery(window).width(),
				tbHeight = jQuery(window).height(),
				tbWidth = ( 720 < width ) ? 720 : width;
			
			tbWidth = tbWidth - 80;
			tbHeight = tbHeight - 84;

			var tbOptions = "<div id='shortcodes_div'><form id='shortcodes'><table id='shortcodes_table' class='form-table "+ tag +"'>";
			tbOptions += outputOptions;
			tbOptions += '</table>\n<p class="submit">\n<input type="button" id="shortcodes-submit" class="button-primary" value="OK" name="submit" /></p>\n</form></div>';
			
			var form = jQuery(tbOptions);
			
			var table = form.find('table');
			form.appendTo('body').hide();
			
			
			if (tag === 'tabs') {
				$moreTabs = jQuery('<p><a href="#" id="add_more_tabs">+ Add Another Tab</a></p>').appendTo('form#shortcodes tbody');
				$moreTabsLink = jQuery('a#add_more_tabs');
				
				$moreTabsLink.live('click',function() {
					var clonedElements = jQuery('form#shortcodes .cloned');
										
					newElements = clonedElements.slice(0,2).clone();
								
					var cloneNumber = clonedElements.length,
						labelNum = cloneNumber / 2;
					
					newElements.each(function(index){
						if ( index === 0 ) jQuery(this).css({'border-top':'1px solid #eeeeee'});
						
						var label = jQuery(this).find('label').attr('for'),
							newLabel = label + labelNum;
					
						jQuery(this).find('label').attr('for',newLabel);
						jQuery(this).find('input, textarea').attr('id',newLabel);
					});
					
					newElements.appendTo('form#shortcodes tbody');
					$moreTabs.appendTo('form#shortcodes tbody');
					return false;
				});		
			}
			
			if (tag === 'slider') {
				$moreImages = jQuery('<p><a href="#" id="add_more_images">+ Add Another Image</a></p>').appendTo('form#shortcodes tbody');
				$moreImagesLink = jQuery('a#add_more_images');
				
				$moreImagesLink.live('click',function() {
					var clonedElements = jQuery('form#shortcodes .cloned');
										
					newElements = clonedElements.slice(0,2).clone();
								
					var cloneNumber = clonedElements.length,
						labelNum = cloneNumber / 2;
					
					newElements.each(function(index){
						if ( index === 0 ) jQuery(this).css({'border-top':'1px solid #eeeeee'});
						
						var label = jQuery(this).find('label').attr('for'),
							newLabel = label + labelNum;
					
						jQuery(this).find('label').attr('for',newLabel);
						jQuery(this).find('input, textarea').attr('id',newLabel);
					});
					
					newElements.appendTo('form#shortcodes tbody');
					$moreImages.appendTo('form#shortcodes tbody');
					return false;
				});		
			}
			
			form.find('#shortcodes-submit').click(function(){
							
				var shortcode = '['+tag;
								
				for( var index in defaultSettings[tag]) {
					var value = table.find('#' + index).val();
					if (index === 'content') { 
						content = value;
						continue;
					}
					
					if (defaultSettings[tag][index]['clone'] !== undefined) {
						content = 'cloned';
						continue;
					} 
					
					if ( value !== defaultSettings[tag][index]['defaultvalue'] )
						shortcode += ' ' + index + '="' + value + '"';
						
				}
				
				
				shortcode += ']<br />\n';
				
				if (content != '') {
					
					if (tag === 'tabs') {
					
						var $form = jQuery('form#shortcodes'),
							tabsOutput = '',
							prefix = '';
							dimensions = '';
						
						tabsOutput += '['+prefix+'tabcontainer]<br />\n';
						$form.find("input[name='tabtext[]']").each(function(){
							tabsOutput += '['+prefix+'tabtext]'+jQuery(this).val()+'[/'+prefix+'tabtext]<br />\n';
						});
						tabsOutput += '[/'+prefix+'tabcontainer]<br />\n';					
						
						
						tabsOutput += '[tabcontent]<br />\n';
						$form.find("textarea[name='tabcontent[]']").each(function(){
							tabsOutput += '['+prefix+'tab'+dimensions+']<br />\n'+jQuery(this).val()+'<br />\n[/'+prefix+'tab]<br />'+"\n";
						});
						
						tabsOutput += '[/tabcontent]\n';
						
						content = tabsOutput;
					}
					
					if (tag === 'slider') {
					
						var $form = jQuery('form#shortcodes'),
							sliderOutput = '',
							prefix = '';
							dimensions = '';
							
						var imgCaption = $form.find("input[name='imgCaption[]']");
						
						$form.find("input[name='imgLink[]']").each(function(){
							sliderOutput += '['+prefix+'image width="'+jQuery("tr:nth-child(2) td input", jQuery(this).parent().parent().parent()).val()+'" height="'+jQuery("tr:nth-child(3) td input", jQuery(this).parent().parent().parent()).val()+'" caption="'+jQuery("input", jQuery(this).parent().parent().next()).val()+'" link="'+jQuery(this).val()+'"]<br />'+"\n";
						});
						
						content = sliderOutput;
					}

				
					shortcode += content;
					shortcode += '\n[/'+tag+'] ' + "\n";
				}

				tinyMCE.activeEditor.execCommand('mceInsertContent', 0, shortcode + ' ');
				
				tb_remove();
			});
			
			tb_show( tag + ' Shortcode', '#TB_inline?width=' + tbWidth + '&height=' + tbHeight + '&inlineId=shortcodes_div' );
			jQuery('#shortcodes_div').remove();
			outputOptions = '';
		}
		
		jQuery(document).ready(function(){	
			jQuery('input[name^="tabtext"]').parents('tr.cloned').hide();
		});
	</script>
<?php } ?>