<?php

add_action('init','of_options');

if (!function_exists('of_options')) {
function of_options(){
	
// VARIABLES
$themename = get_theme_data(STYLESHEETPATH . '/style.css');
$themename = $themename['Name'];
$shortname = "of";

// Populate OptionsFramework option in array for use in theme
global $of_options;
$of_options = get_option('of_options');

$GLOBALS['template_path'] = OF_DIRECTORY;

//Access the WordPress Categories via an Array
$of_categories = array();  
$of_categories_obj = get_categories('hide_empty=0');
foreach ($of_categories_obj as $of_cat) {
    $of_categories[$of_cat->cat_ID] = $of_cat->cat_name;}
$categories_tmp = array_unshift($of_categories, "Select a category:");    
       
//Access the WordPress Pages via an Array
$of_pages = array();
$of_pages_obj = get_pages('sort_column=post_parent,menu_order');    
foreach ($of_pages_obj as $of_page) {
    $of_pages[$of_page->ID] = $of_page->post_name; }
$of_pages_tmp = array_unshift($of_pages, "Select a page:");       

// Image Alignment radio box
$options_thumb_align = array("alignleft" => "Left","alignright" => "Right","aligncenter" => "Center"); 

// Image Links to Options
$options_image_link_to = array("image" => "The Image","post" => "The Post"); 

//More Options
$uploads_arr = wp_upload_dir();
$all_uploads_path = $uploads_arr['path'];
$all_uploads = get_option('of_uploads');
$other_entries = array("Select a number:","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
$body_repeat = array("no-repeat","repeat-x","repeat-y","repeat");
$body_pos = array("top left","top center","top right","center left","center center","center right","bottom left","bottom center","bottom right");

// Set the Options Array
$options = array();                                       
					
					
$options[] = array( "name" => "Theme &amp; Style",
                    "desc" => "This section provides control over the main styling of your site. Hover over the '?' symbols for additional info about options.",
                    "icon" => "style",
                    "type" => "heading");
                    
$url =  OF_DIRECTORY . '/admin/images/themes/';
$options[] = array( "name" => "Main Theme",
					"desc" => "Select a main theme for your site.",
					"id" => $shortname."_main_theme",
					"std" => "stripeBlue",
					"type" => "images",
					"options" => array(
						'woodBlue' => $url . 'darkWoodBlueIcon.jpg',
						'woodGreen' => $url . 'darkWoodGreenIcon.jpg',
						'woodRed' => $url . 'darkWoodRedIcon.jpg',
						'woodYellow' => $url . 'darkWoodYellowIcon.jpg',
						'stripeBlue' => $url . 'darkStripeBlueIcon.jpg',
						'stripeGreen' => $url . 'darkStripeGreenIcon.jpg',
						'stripeRed' => $url . 'darkStripeRedIcon.jpg',
						'stripeYellow' => $url . 'darkStripeYellowIcon.jpg',
						'hatchBlue' => $url . 'darkHatchBlueIcon.jpg',
						'hatchGreen' => $url . 'darkHatchGreenIcon.jpg',
						'hatchRed' => $url . 'darkHatchRedIcon.jpg',
						'hatchYellow' => $url . 'darkHatchYellowIcon.jpg',
						'boxBlue' => $url . 'darkBoxBlueIcon.jpg',
						'boxGreen' => $url . 'darkBoxGreenIcon.jpg',
						'boxRed' => $url . 'darkBoxRedIcon.jpg',
						'boxYellow' => $url . 'darkBoxYellowIcon.jpg',
));

$options[] = array( "name" => "Display Font Method",
					"desc" => "The method used for font replacement. Cufon (Javascript) or @font-face (CSS).",
					"id" => $shortname."_font_method",
					"std" => "cufon",
					"type" => "select2",
					"options" => array(
						'cufon' => 'Cufon',
						'font-face' => '@font-face'));
						
$options[] = array( "name" => "Home Slider Border Colour for Active Thumbnail",
					"desc" => "If using the slider for the featured area, this setting controls the border color of the active thumbnail. (Default is #3F3F3F.)",
					"id" => $shortname."_slider_active_thumb_border_color",
					"std" => "#3F3F3F",
					"type" => "color");
					
$options[] = array( "name" => "Custom CSS",
                    "desc" => "Quickly add some CSS to your theme by adding it to this block.",
                    "id" => $shortname."_custom_css",
                    "std" => "",
                    "type" => "textarea");
                    
                    
                    
                    					
$options[] = array( "name" => "Logo &amp; Favicon",
					"desc" => "This section provides a simple way to upload your custom site logo and favicon. An example logo PSD file is included in the Themeforest download.",
					"icon" => "logo",
                    "type" => "heading");
                    
$options[] = array( "name" => "Header Logo",
					"desc" => "Upload a logo for your theme header.",
					"id" => $shortname."_header_logo",
					"std" => "",
					"type" => "upload_min");
					
$options[] = array( "name" => "Header Logo Height",
					"desc" => "Enter the pixel height of your chosen header logo image, e.g. '50'",
					"id" => $shortname."_header_logo_height",
					"std" => "",
					"type" => "text");
					
$options[] = array( "name" => "Footer Logo",
					"desc" => "Upload a logo for your theme footer.",
					"id" => $shortname."_footer_logo",
					"std" => "",
					"type" => "upload_min");
					
$options[] = array( "name" => "Footer Logo Height",
					"desc" => "Enter the pixel height of your chosen footer logo image, e.g. '30'",
					"id" => $shortname."_footer_logo_height",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Custom Favicon",
					"desc" => "Upload a 16px x 16px PNG/GIF image that will represent your website's favicon.",
					"id" => $shortname."_custom_favicon",
					"std" => "",
					"type" => "upload_min"); 
					
					
                    
$options[] = array( "name" => "Featured Area",
					"desc" => "This section provides control over the featured area on the home page.",
					"icon" => "featured",
                    "type" => "heading"); 
                    
$options[] = array( "name" => "Homepage Featured Area",
					"desc" => "Choose between a slider, an accordion and a still image.",
					"id" => $shortname."_home_featured",
					"std" => "slider",
					"type" => "select2",
					"options" => array(
						'slider' => 'Slider',
						'accordion' => 'Accordion',
						'single_post' => 'Single Post'));
						
$options[] = array( "name" => "Select a Featured Category",
					"desc" => "Choose any category for the featured area to pull posts from. Bear in mind that posts in this category should have featured images large enough to fill the featured area.",
					"id" => $shortname."_featured_category",
					"std" => "Select a category:",
					"type" => "select",
					"options" => $of_categories);
					
$options[] = array( "name" => "Featured Area Height",
					"desc" => "Enter the pixel height that the featured area will occupy, e.g. '380'. (The width is 970.)",
					"id" => $shortname."_featured_area_height",
					"std" => "380",
					"type" => "text");
					
$options[] = array( "name" => "Display Caption on Featured Area?",
					"desc" => "If checked, the title & excerpt of featured posts/pages/portfolio items will be overlaid on the featured area.",
					"id" => $shortname."_home_slider_caption",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Display Ribbon on Featured Area?",
					"desc" => "If set, displays a ribbon with the text, 'Featured', overlaid on the featured area.",
					"id" => $shortname."_home_featured_ribbon",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Slider Caption Alignment",
					"desc" => "This setting controls the placement of the title/caption overlay for the slider.",
					"id" => $shortname."_slider_caption_alignment",
					"std" => "full",
					"type" => "select2",
					"options" => array(
						'full' => 'Full Width',
						'left' => 'Left',
						'right' => 'Right'));
						
				
					
$options[] = array( "name" => "Sliders",
					"desc" => "This section provides control over any sliders used on your site (including the featured area if you have opted to use a slider there).",
					"icon" => "sliders",
                    "type" => "heading");
                    
$options[] = array( "name" => "Transition Effect",
					"desc" => "The type of animation between slides.",
					"id" => $shortname."_slider_effect",
					"std" => "random",
					"type" => "select2",
					"options" => array(
						'random' => 'Random',
						'sliceDown' => 'Slice Down',
						'sliceDownLeft' => 'Slice Down Left',
						'sliceUp' => 'Slice Up',
						'sliceUpLeft' => 'Slice Up Left',
						'sliceUpDownLeft' => 'Slice Up Down Left',
						'fold' => 'Fold',
						'fade' => 'Fade',
						'slideInRight' => 'Slide In Right',
						'slideInLeft' => 'Slide In Left',
						'boxRandom' => 'Box Random',
						'boxRain' => 'Box Rain',
						'boxRainReverse' => 'Box Rain Reverse',
						'boxRainGrow' => 'Box Rain Grow',
						'boxRainGrowReverse' => 'Box Rain Grow Reverse'));
						
$options[] = array( "name" => "Auto Play the Slider?",
					"desc" => "If set, sliders will auto play when the page is loaded.",
					"id" => $shortname."_slider_autostart",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Animation Speed",
					"desc" => "The speed of the animation (in milliseconds).",
					"id" => $shortname."_slider_anim_speed",
					"std" => "500",
					"type" => "text");
					
$options[] = array( "name" => "Pause Time Between Slides",
					"desc" => "If auto play is set to be on, this setting will adjust the speed between slide changes (in milliseconds).",
					"id" => $shortname."_slider_pause_time",
					"std" => "5000",
					"type" => "text");
					
$options[] = array( "name" => "Starting Slide",
					"desc" => "The slide that will be active when the slider loads.",
					"id" => $shortname."_slider_start_slide",
					"std" => "0",
					"type" => "select2",
					"options" => array(
						'0' => '1',
						'1' => '2',
						'2' => '3',
						'3' => '4',
						'4' => '5'));
						
					
$options[] = array( "name" => "Home Page",
					"desc" => "This section provides control over the main content area of your home page.",
					"icon" => "home",
                    "type" => "heading");
					
$options[] = array( "name" => "Home Message",
					"desc" => "Your site's welcome message.",
					"id" => $shortname."_home_message",
					"std" => "Welcome, Bienvenue&hellip;",
					"type" => "text"); 
						
$options[] = array( "name" => "Homepage Content",
					"desc" => "Choose between displaying blog posts or custom content on the home page.",
					"id" => $shortname."_home_content",
					"std" => "blog_posts",
					"type" => "select2",
					"options" => array(
						'blog_posts' => 'Blog Posts',
						'custom_content' => 'Custom Content',
						'both' => 'Both'));
						
$options[] = array( "name" => "Number of Columns for Home Blog Posts Display",
					"desc" => "Choose the number of columns for the home blog posts display.",
					"id" => $shortname."_home_columns",
					"std" => "three",
					"type" => "select2",
					"options" => array(
						'one' => 'One Column',
						'two' => 'Two Columns',
						'three' => 'Three Columns'));
						
$options[] = array( "name" => "Display Sidebar on Home Blog Display?",
					"desc" => "If checked, you must select either one or two columns above (not three).",
					"id" => $shortname."_home_sidebar",
					"std" => "false",
					"type" => "checkbox");
						
$options[] = array( "name" => "How Many Posts Shown on Home Page?",
					"desc" => "Choose the number of posts displayed on the home page.",
					"id" => $shortname."_home_posts_shown",
					"std" => "3",
					"type" => "select2",
					"options" => array(
						'1' => 'One',
						'2' => 'Two',
						'3' => 'Three',
						'4' => 'Four',
						'5' => 'Five',
						'6' => 'Six',
						'7' => 'Seven',
						'8' => 'Eight',
						'9' => 'Nine',
						'10' => 'Ten'));
						
						
$options[] = array( "name" => "Blog",
					"desc" => "This section provides control over the layout of your blog overview.",
					"icon" => "blog",
                    "type" => "heading");

$options[] = array( "name" => "Number of Columns for Blog Overview",
					"desc" => "Choose the number of columns for the blog overview.",
					"id" => $shortname."_blog_columns",
					"std" => "two",
					"type" => "select2",
					"options" => array(
						'one' => 'One Column',
						'two' => 'Two Columns',
						'three' => 'Three Columns'));
						
$options[] = array( "name" => "Display Sidebar on Blog Overview?",
					"desc" => "If checked, you must select either one or two columns above (not three).",
					"id" => $shortname."_blog_sidebar",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "How Many Posts Shown on Blog Overview?",
					"desc" => "Choose the number of posts displayed on blog overview.",
					"id" => $shortname."_blog_posts_shown",
					"std" => "4",
					"type" => "select2",
					"options" => array(
						'1' => 'One',
						'2' => 'Two',
						'3' => 'Three',
						'4' => 'Four',
						'5' => 'Five',
						'6' => 'Six',
						'7' => 'Seven',
						'8' => 'Eight',
						'9' => 'Nine',
						'10' => 'Ten'));	
						
$options[] = array( "name" => "Display Sidebar on Single Blog Entry?",
					"desc" => "If checked, sidebar will be displayed on blog entries. Customise under Appearance > Widgets.",
					"id" => $shortname."_blog_item_sidebar",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Display Meta Info for Blog Items?",
					"desc" => "If checked, meta info (e.g. category, date, comments) will be displayed for blog posts on the blog overview and single entry views.",
					"id" => $shortname."_blog_meta_display",
					"std" => "true",
					"type" => "checkbox");
					
					
$options[] = array( "name" => "".get_option('of_portfolio_name')."",
					"desc" => "This section provides control over the layout of your portfolio overview.",
					"icon" => "portfolio",
                    "type" => "heading");
                    
$options[] = array( "name" => "Your Portfolio Name",
					"desc" => "If you'd like your portfolio to be named something other than 'Portfolio,' enter this here.",
					"id" => $shortname."_portfolio_name",
					"std" => "Portfolio",
					"type" => "text"); 

$options[] = array( "name" => "Number of Columns for Portfolio Overview",
					"desc" => "Choose the number of columns for the portfolio overview.",
					"id" => $shortname."_portfolio_columns",
					"std" => "one",
					"type" => "select2",
					"options" => array(
						'one' => 'One Column',
						'two' => 'Two Columns',
						'three' => 'Three Columns'));
						
$options[] = array( "name" => "Display Sidebar on Portfolio Overview?",
					"desc" => "If checked, you must select either one or two columns above (not three).",
					"id" => $shortname."_portfolio_sidebar",
					"std" => "false",
					"type" => "checkbox");
					
$options[] = array( "name" => "Posts Shown on Portfolio Overview",
					"desc" => "Choose the number of posts displayed on portfolio overview.",
					"id" => $shortname."_portfolio_posts_shown",
					"std" => "4",
					"type" => "select2",
					"options" => array(
						'1' => 'One',
						'2' => 'Two',
						'3' => 'Three',
						'4' => 'Four',
						'5' => 'Five',
						'6' => 'Six',
						'7' => 'Seven',
						'8' => 'Eight',
						'9' => 'Nine',
						'10' => 'Ten'));
						
$options[] = array( "name" => "Display Sidebar on Single Portfolio Entry?",
					"desc" => "If checked, sidebar will be displayed on blog entries. Customise under Appearance > Widgets.",
					"id" => $shortname."_portfolio_item_sidebar",
					"std" => "false",
					"type" => "checkbox");
					
$options[] = array( "name" => "Display Meta Info for Portfolio Items?",
					"desc" => "If checked, meta info (e.g. category, date, comments) will be displayed for portfolio items on the portfolio overview and single entry views.",
					"id" => $shortname."_portfolio_meta_display",
					"std" => "true",
					"type" => "checkbox");
					
					
$options[] = array( "name" => "Contact Form",
					"desc" => "This section provides a simple way to direct mail to your chosen email address if using the built-in theme contact form.",
					"icon" => "contact",
                    "type" => "heading");
                    
$options[] = array( "name" => "Recipient Email Address",
					"desc" => "The email address that all contact form entries will be sent to.",
					"id" => $shortname."_recipient_email",
					"std" => "",
					"type" => "text");
			
						
$options[] = array( "name" => "Sidebar Ads",
					"desc" => "This section provides control over the 125x125 sidebar adverts widget (you must also add this widget to your sidebar).",
					"icon" => "ads",
                    "type" => "heading");
                    
$options[] = array( "name" => "Open Advert Links in New Tab?",
					"desc" => "If checked, advert links will open in a new tab.",
					"id" => $shortname."_advert_new_tab",
					"std" => "false",
					"type" => "checkbox");

$options[] = array( "name" => "Advert 1 Link",
					"desc" => "The link that advert 1 will direct to.",
					"id" => $shortname."_ad_125_1_text",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "Advert 1 Image",
					"desc" => "Upload a 125px x 125px advert image.",
					"id" => $shortname."_ad_125_1_img",
					"std" => '',
					"type" => "upload_min");
					
$options[] = array( "name" => "Advert 2 Link",
					"desc" => "The link that advert 2 will direct to.",
					"id" => $shortname."_ad_125_2_text",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "Advert 2 Image",
					"desc" => "Upload a 125px x 125px advert image.",
					"id" => $shortname."_ad_125_2_img",
					"std" => '',
					"type" => "upload_min");
					
$options[] = array( "name" => "Advert 3 Link",
					"desc" => "The link that advert 3 will direct to.",
					"id" => $shortname."_ad_125_3_text",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "Advert 3 Image",
					"desc" => "Upload a 125px x 125px advert image.",
					"id" => $shortname."_ad_125_3_img",
					"std" => '',
					"type" => "upload_min");
					
$options[] = array( "name" => "Advert 4 Link",
					"desc" => "The link that advert 4 will direct to.",
					"id" => $shortname."_ad_125_4_text",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "Advert 4 Image",
					"desc" => "Upload a 125px x 125px advert image.",
					"id" => $shortname."_ad_125_4_img",
					"std" => '',
					"type" => "upload_min");
					
					
$options[] = array( "name" => "Social Media",
					"desc" => "This section provides control over the social networking icons that display next to the comment form on blog posts. Use these icons to link to any social media presences you may have.",
					"icon" => "social",
                    "type" => "heading");
                    
$options[] = array( "name" => "Show Social Networking Links in Comment Section?",
					"desc" => "If checked, social networking links will be displayed next to comment form.",
					"id" => $shortname."_show_social_links",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Social Links Heading",
					"desc" => "The heading above the social media links.",
					"id" => $shortname."_social_links_heading",
					"std" => 'Share with Social Media',
					"type" => "text");
                    
$options[] = array( "name" => "Open Social Networking Links in New Tab?",
					"desc" => "If checked, social networking links will open in a new tab.",
					"id" => $shortname."_social_new_tab",
					"std" => "false",
					"type" => "checkbox");

$options[] = array( "name" => "Facebook Link",
					"desc" => "The link to your Facebook page.",
					"id" => $shortname."_facebook",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "Twitter Link",
					"desc" => "The link to your Twitter page.",
					"id" => $shortname."_twitter",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "Tumblr Link",
					"desc" => "The link to your Tumblr page.",
					"id" => $shortname."_tumblr",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "Stumble Upon Link",
					"desc" => "The link to your Stumble Upon page.",
					"id" => $shortname."_stumbleupon",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "Delicious Link",
					"desc" => "The link to your Delicious page.",
					"id" => $shortname."_delicious",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "Reddit Link",
					"desc" => "The link to your Reddit page.",
					"id" => $shortname."_reddit",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "Flickr Link",
					"desc" => "The link to your Flickr page.",
					"id" => $shortname."_flickr",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "LinkedIn Link",
					"desc" => "The link to your LinkedIn page.",
					"id" => $shortname."_linkedin",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "Last.fm Link",
					"desc" => "The link to your Last.fm page.",
					"id" => $shortname."_lastfm",
					"std" => '',
					"type" => "text");
					
$options[] = array( "name" => "Digg Link",
					"desc" => "The link to your Digg page.",
					"id" => $shortname."_digg",
					"std" => '',
					"type" => "text");
					

$options[] = array( "name" => "General Settings",
					"desc" => "This section provides control over various other aspects of the theme.",
					"icon" => "general",
                    "type" => "heading");
                    
$options[] = array( "name" => "Which Widgetised Footer Should be Used?",
					"desc" => "Please make sure you have the correct number of widgets in your footer under Appearance > Widgets.",
					"id" => $shortname."_footer_widget_count",
					"std" => "four",
					"type" => "select2",
					"options" => array(
						'four' => 'Four Widget Footer',
						'three' => 'Three Widget Footer'));		
                                               
$options[] = array( "name" => "Tracking Code",
					"desc" => "Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme.",
					"id" => $shortname."_google_analytics",
					"std" => "",
					"type" => "textarea");
					
$options[] = array( "name" => "Load jQuery from Google CDN?",
					"desc" => "This is recommended to increase speed. However, if this jQuery version conflicts with a plugin then disable this setting and the jQuery version packaged with WordPress will be automatically used instead.",
					"id" => $shortname."_google_jquery",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Show Link to RSS Feed in Header?",
					"desc" => "If checked, a link to your site's RSS feed will show in the header.",
					"id" => $shortname."_header_rss_link",
					"std" => "true",
					"type" => "checkbox");
					
					
					
$options[] = array( "name" => "Translation",
					"desc" => "This section provides a simple way to modify the hardcoded text used in the theme.",
					"icon" => "translation",
                    "type" => "heading");
                    
$options[] = array( "name" => "Footer Copyright",
					"desc" => "The copyright text. This will be followed by the current year and site name.",
					"id" => $shortname."_trans_footer_copy",
					"std" => "Copyright &copy;",
					"type" => "text");
					
$options[] = array( "name" => "Footer Text",
					"desc" => "The text displayed after the footer copyright notice.",
					"id" => $shortname."_trans_footer_text",
					"std" => "All Rights Reserved.",
					"type" => "text");
					
$options[] = array( "name" => "Search Placeholder",
					"desc" => "This will be displayed in the searchbox in modern browsers that support the HTML5 placeholder input attribute.",
					"id" => $shortname."_trans_search_placeholder",
					"std" => "Search&hellip;",
					"type" => "text");
					
$options[] = array( "name" => "RSS Text",
					"desc" => "The text for the header RSS link. This can be disabled entirely in General Settings.",
					"id" => $shortname."_trans_rss_text",
					"std" => "Subscribe via RSS",
					"type" => "text");
					
$options[] = array( "name" => "Home Breadcrumb Link",
					"desc" => "The text for the breadcrumb link that leads visitors back to the homepage.",
					"id" => $shortname."_trans_breadcrumb_home_link",
					"std" => "Home",
					"type" => "text");
                    
$options[] = array( "name" => "404 Title",
					"desc" => "The title displayed on your 404 page (displayed if a visitor follows a broken link).",
					"id" => $shortname."_trans_404_title",
					"std" => "Page Not Found",
					"type" => "text");	
					
$options[] = array( "name" => "404 Body Text",
					"desc" => "The text displayed on your 404 page underneath the title.",
					"id" => $shortname."_trans_404_text",
					"std" => "Sorry, but the page you are looking for could not be found.<br />If this seems to be an error on our part, please consider notifying us to let us know. We appreciate any and all information relating to broken links and other potential issues with site structure.",
					"type" => "textarea");


update_option('of_template',$options); 					  
update_option('of_themename',$themename);   
update_option('of_shortname',$shortname);

}
}
?>
