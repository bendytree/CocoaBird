/*
 * Fade Slider Toggle plugin
 * 
 * Copyright(c) 2009, Cedric Dugas
 * http://www.position-relative.net
 *	
 * A sliderToggle() with opacity
 * Licenced under the MIT Licence
 */


 jQuery.fn.fadeSliderToggle = function(settings) {
 	/* Damn you jQuery opacity:'toggle' that dosen't work!~!!!*/
 	 settings = jQuery.extend({
		speed: 250
	}, settings)
	
	caller = this
 	if(jQuery(caller).css("display") == "none"){
 		jQuery(caller).animate({
 			opacity: 1,
 			height: 'toggle'
 		}, settings.speed, settings.easing);
	}else{
		jQuery(caller).animate({
 			opacity: 0,
 			height: 'toggle'
 		}, settings.speed, settings.easing);
	}
}; 

//Hide (Collapse) the toggle containers on load
jQuery(".option").hide(); 

//Switch the "Open" and "Close" state per click then slide up/down (depending on open/close state)
jQuery(".triggerButton").click(function(){
	
	if (jQuery(this).parent().hasClass('active')) {
		jQuery(this).parent().removeClass("active").next().fadeSliderToggle();
	} else {
		jQuery(this).parent().addClass("active").next().fadeSliderToggle();
		return false; //Prevent the browser jump to the link anchor
	}
});


jQuery('.upload_button_div').click(function() {
	jQuery('*').addClass('active');
});