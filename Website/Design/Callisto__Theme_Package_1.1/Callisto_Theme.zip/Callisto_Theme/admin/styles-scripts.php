<?php
/*-----------------------------------------------------------------------------------*/
/* Enqueue Additional Styles
/*-----------------------------------------------------------------------------------*/

function enqueue_theme_styles() {
	global $post;
    if(!is_admin() && $pagenow != 'wp-login.php') {
     
    	//First load essential styles (included on every page)
    	wp_enqueue_style( 'maintheme', get_template_directory_uri().'/styles/themes/'.get_option('of_main_theme').'.css', '', '', 'screen' );
    	
    	//If @font-face is enabled, load @font-face stylesheet (this in turn references the font locations)
    	if (get_option('of_font_method') == 'font-face') wp_enqueue_style( 'font-face', get_template_directory_uri().'/fonts/font-face/ubuntu-regular/ubuntu-regular.css', '', '', 'screen' );
    	
    	//Then load optional styles (depending on page content)
		if (is_page_template('portfolio.php')) wp_enqueue_style( 'prettyphoto-style', get_template_directory_uri().'/styles/prettyPhoto.css', '', '', 'screen' );
        if (strpos($post->post_content, 'prettyprint') !== false || strpos($post->post_content, 'pre_pretty') !== false || strpos($post->post_content, 'code_pretty') !== false) wp_enqueue_style( 'prettify-style', get_template_directory_uri().'/styles/prettify.css', '', '', 'screen' );     
        
    }
}    
 
add_action('wp_print_styles', 'enqueue_theme_styles');


/*-----------------------------------------------------------------------------------*/
/* Enqueue Additional Scripts
/*-----------------------------------------------------------------------------------*/

function enqueue_theme_scripts() {
	global $post;
	if(!is_admin() && $pagenow != 'wp-login.php') {
		
		// If option is set, deregister WP version of jQuery, then register jQuery from Google's CDN (faster and maybe already cached by visitor)
		if (get_option('of_google_jquery') == 'true') { wp_deregister_script( 'jquery' );
			wp_register_script( 'jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/1.6.0/jquery.min.js'); 
		}
		
		//Enqueue jQuery
		wp_enqueue_script( 'jquery' );
		
		//Load essential scripts (included on every page)
		wp_enqueue_script('jquery-nav', get_template_directory_uri().'/js/jquery-nav.js', 'jquery', '');
		wp_enqueue_script('init', get_template_directory_uri().'/js/init.js', 'jquery', '', true);
		
		//If Cufon is enabled, load cufon script
		if (get_option('of_font_method') == 'cufon' || get_option('of_font_method') == '') wp_enqueue_script('cufon', get_template_directory_uri().'/fonts/cufon/cufon.js', 'jquery', '');

		//Load optional scripts (depending on page content)
		if (is_page_template('custom-home-page.php') && get_option('of_home_content') == 'blog_posts' && get_option('of_home_columns') != 'one' || is_page_template('custom-home-page.php') && get_option('of_home_content') == 'both' && get_option('of_home_columns') != 'one'  || strpos($post->post_content, 'masonry') !== false || is_archive() && get_option('of_blog_columns') != 'one' || is_page_template('portfolio.php') && get_option('of_portfolio_columns') != 'one' || is_home() && get_option('of_blog_columns') != 'one' || is_search() && get_option('of_blog_columns') != 'one' || is_page_template('custom-blank.php') || is_page_template('custom-blank-with-sidebar.php')) wp_enqueue_script('masonry', get_template_directory_uri().'/js/masonry.js', 'jquery', '', true);
		if (is_page_template('custom-home-page.php') && get_option('of_home_featured') == 'slider' || strpos($post->post_content, 'slider') !== false || strpos(get_option('sidebars_widgets'), 'slider') !== false) wp_enqueue_script('nivoslider', get_template_directory_uri().'/js/jquery.nivo.slider.js', 'jquery', '', true);
		if (is_page_template('custom-home-page.php') && get_option('of_home_featured') == 'slider') wp_enqueue_script('tooltip', get_template_directory_uri().'/js/tiptip.js', 'jquery', '', true);
		if (is_page_template('custom-home-page.php') && get_option('of_home_featured') == 'accordion' || is_page_template('demo-home-accordion.php')) wp_enqueue_script('accordion', get_template_directory_uri().'/js/kwicks.js', 'jquery', '', true);
		if (is_page_template('portfolio.php')) wp_enqueue_script('prettyphoto', get_template_directory_uri().'/js/prettyPhoto.js', 'jquery', '', true);
		if (strpos($post->post_content, 'prettyprint') !== false || strpos($post->post_content, 'pre_pretty') !== false || strpos($post->post_content, 'code_pretty') !== false) wp_enqueue_script('prettify', get_template_directory_uri().'/js/prettify.js', 'jquery', '', true);
		if (strpos($post->post_content, 'contact_form') !== false) wp_enqueue_script('contactform', get_template_directory_uri().'/js/contact-form.js', 'jquery', '', true);
		
	}
}

add_action('wp_print_scripts', 'enqueue_theme_scripts');
?>