<?php
/*
Template Name: Portfolio
*/
get_header(); ?>

<section>
	<header class="titleSpace">
		<div class="container group">
			<h1><?php the_title(); ?></h1>
			<?php if (function_exists('breadcrumbs')) breadcrumbs(); ?>
		</div> <!-- /.container -->
	</header> <!-- /.titleSpace -->
	
	<div class="container group">
		<div class="containerInner group">
			<?php if (get_option('of_portfolio_sidebar') == 'true') echo '<div class="pageHolder group">'; ?>
				<?php if (get_option('of_portfolio_columns') == 'two' || get_option('of_portfolio_columns') == 'three') echo '<div class="masonry group">'; ?>
					
					<?php
					$temp = $wp_query;
					$wp_query = null;
					$wp_query = new WP_Query();
					$wp_query->query('post_type=portfolios&posts_per_page='.get_option("of_portfolio_posts_shown").'&paged='.$paged);
					while ($wp_query->have_posts()) : $wp_query->the_post(); ?>
				
					<section class="pageBlock group <?php if (get_option('of_portfolio_columns') == 'one' && get_option('of_portfolio_sidebar') == 'false') echo ''; elseif (get_option('of_portfolio_columns') == 'one' && get_option('of_portfolio_sidebar') == 'true') echo 'boxTwoThirds';  elseif  (get_option('of_portfolio_columns') == 'two' && get_option('of_portfolio_sidebar') == 'false') echo 'boxOneHalf';  else  echo 'boxOneThird'; ?>">
						<span class="pageTop"></span>
						<div class="pageMiddle group">
							
							<?php if (get_option('of_portfolio_columns') == 'one') $thumbSize = 'large'; elseif (get_option('of_portfolio_columns') == 'two' && get_option('of_portfolio_sidebar') == 'false') $thumbSize = 'medium'; else $thumbSize = 'small'; ?>
							<?php if (get_option('of_portfolio_columns') == 'one' && get_option('of_portfolio_sidebar') == 'false') $largeClass = 'twoThirds first'; ?>
							<?php if ( has_post_thumbnail() ) {
								$image_id = get_post_thumbnail_id();  
								$image_url = wp_get_attachment_image_src($image_id,'full'); 
								$image_url = $image_url[0];
								echo '<a href="';
								echo $image_url;
								echo '" class="preloadHolder group '.$largeClass.'" rel="lightbox[portfolio]">';
							    the_post_thumbnail('callisto_'.$thumbSize, array('class' => 'postThumb preloadMe zoomMe'));
							    echo '</a>';
							} ?>
							
							<?php if  (get_option('of_portfolio_columns') == 'one' && get_option('of_portfolio_sidebar') == 'false') echo '<div class="portfolioInfo oneThird">';  ?>
								<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								
								<?php if (get_option('of_portfolio_meta_display') == 'true' || get_option('of_portfolio_meta_display') == '') { ?>
									<footer class="cal_post_meta">
										<ul>
											<li class="metaDate"><time datetime="<?php the_time('c') ?>" pubdate><?php the_time('l, F jS, Y') ?></time></li>
											<?php
												echo '<li class="metaCat">';
												echo the_category(', ') . '</li>';
											if (has_tag()) {
												echo '<li class="metaTag">';
												echo the_tags('', ', ') . '</li>';
											} ?>
										</ul>
									</footer> <!-- /.cal_post_meta -->
								<?php } ?>
									
								<?php the_excerpt(); ?>
								<a href="<?php the_permalink(); ?>" class="button <?php if (get_option('of_portfolio_columns') == 'two' && get_option('of_portfolio_sidebar') == 'true' || get_option('of_portfolio_columns') == 'three') echo 'width100'; ?>">
									<div>
										<p>Read More</p>
									</div>
								</a> <!-- /.button -->
							<?php if  (get_option('of_portfolio_columns') == 'one' && get_option('of_portfolio_sidebar') == 'false') echo '</div> <!-- /.portfolioInfo -->';  ?>
						
						</div> <!-- /.pageMiddle -->
						<span class="pageBottom"></span>
						<span class="pageShadow"></span>
					</section> <!-- /.pageBlock -->
					
					<?php endwhile; ?>
				
				<?php if  (get_option('of_portfolio_columns') == 'two' || get_option('of_portfolio_columns') == 'three') echo '</div> <!-- /.masonry -->';  ?>
				<?php pagination(); ?>
			<?php if  (get_option('of_portfolio_sidebar') == 'true') echo '</div> <!-- /.pageHolder -->';  ?>
			<?php if (get_option('of_portfolio_sidebar') == 'true') get_sidebar(); ?>
					
			<?php $wp_query = null; $wp_query = $temp;?>
		</div> <!-- /.containerInner -->
	</div> <!-- /.container -->
</section>

<?php get_footer(); ?>