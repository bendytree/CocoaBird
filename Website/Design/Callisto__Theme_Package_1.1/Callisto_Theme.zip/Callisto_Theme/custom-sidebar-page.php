<?php
/*
Template Name: Default Template with Sidebar
*/
get_header(); ?>

<section>
	<header class="titleSpace">
		<div class="container group">
			<h1><?php the_title(); ?></h1>
			<?php if (function_exists('breadcrumbs')) breadcrumbs(); ?>
		</div> <!-- /.container -->
	</header> <!-- /.titleSpace -->
		
	<div class="container group">
		<div class="containerInner group">
			<div class="pageHolder group">
	
				<div class="pageBlock boxTwoThirds">
					<span class="pageTop"></span>
					<div class="pageMiddle group">
						<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
							<?php the_content(); ?>
						<?php endwhile; ?>
					</div> <!-- /.pageMiddle -->
					<span class="pageBottom"></span>
					<span class="pageShadow"></span>
				</div> <!-- /.pageBlock -->
				
			</div> <!-- /.pageHolder -->
			<?php get_sidebar(); ?>
		</div> <!-- /.containerInner -->
	</div> <!-- /.container -->
</section>

<?php get_footer(); ?>