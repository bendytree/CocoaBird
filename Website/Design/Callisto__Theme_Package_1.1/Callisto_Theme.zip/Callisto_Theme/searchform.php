<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
	<input class="searchBox" type="text" value="" name="s" id="s" placeholder="<?php if (get_option('of_trans_search_placeholder') != '') echo stripslashes(get_option('of_trans_search_placeholder')); else echo 'Search&hellip;'; ?>"/>
	<input type="submit" id="searchsubmit" class="searchSubmit" value="Search" />
</form>