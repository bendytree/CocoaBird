<?php if ( comments_open() ) : ?>

<aside class="commentTemplate">
	<header class="subtitleSpace" id="comments">
		<div class="container group">
			<h3><?php
			printf( _n( '1 Response to %2$s', '%1$s Responses to %2$s', get_comments_number() ),
			number_format_i18n( get_comments_number() ), '<em>' . get_the_title() . '</em>' );
			?></h3>
		</div> <!-- /.container -->
	</header> <!-- /.titleSpace -->
	
	<div class="container group">
		<div class="containerInner group">
		
			<?php if ( have_comments() ) : ?>
				<div class="commentHolder">
					<ol class="commentlist">		
						<?php wp_list_comments('callback=callisto_comment'); ?>
					</ol>
				</div>
			<?php endif; ?>
		
			<div class="pageBlock boxTwoThirds">
				<span class="pageTop"></span>
				<div class="pageMiddle group">
					<?php comment_form(); ?>
				</div> <!-- /.pageMiddle -->
				<span class="pageBottom"></span>
				<span class="pageShadow"></span>
			</div> <!-- /.pageBlock -->
			
			<?php if (get_option('of_show_social_links') == 'true') { ?>
				<aside class="pageBlock boxOneThird">
					<span class="pageTop"></span>
					<div class="pageMiddle group">
						<h3><?php echo get_option('of_social_links_heading'); ?></h3>
						<ul class="socialIcons">
							<?php if (get_option('of_social_new_tab') == 'true') $social_new_tab = 'target="_blank"'; ?>
							<?php if (get_option('of_facebook') != '') { ?>
								<li><a href="<?php echo get_option('of_facebook'). '" '. $social_new_tab; ?>><img src="<?php echo bloginfo('template_directory') . '/img/socialIcons/facebookSmall.png'; ?>" alt="" />Facebook</a></li>
							<?php } ?>
							<?php if (get_option('of_twitter') != '') { ?>
								<li><a href="<?php echo get_option('of_twitter'). '" '. $social_new_tab; ?>><img src="<?php echo bloginfo('template_directory') . '/img/socialIcons/twitterSmall.png'; ?>" alt="" />Twitter</a></li>
							<?php } ?>
							<?php if (get_option('of_tumblr') != '') { ?>
								<li><a href="<?php echo get_option('of_tumblr'). '" '. $social_new_tab; ?>><img src="<?php echo bloginfo('template_directory') . '/img/socialIcons/tumblrSmall.png'; ?>" alt="" />Tumblr</a></li>
							<?php } ?>
							<?php if (get_option('of_stumbleupon') != '') { ?>
								<li><a href="<?php echo get_option('of_stumbleupon'). '" '. $social_new_tab; ?>><img src="<?php echo bloginfo('template_directory') . '/img/socialIcons/stumbleuponSmall.png'; ?>" alt="" />Stumble Upon</a></li>
							<?php } ?>
							<?php if (get_option('of_delicious') != '') { ?>
								<li><a href="<?php echo get_option('of_delicious'). '" '. $social_new_tab; ?>><img src="<?php echo bloginfo('template_directory') . '/img/socialIcons/deliciousSmall.png'; ?>" alt="" />Delicious</a></li>
							<?php } ?>
							<?php if (get_option('of_reddit') != '') { ?>
								<li><a href="<?php echo get_option('of_reddit'). '" '. $social_new_tab; ?>><img src="<?php echo bloginfo('template_directory') . '/img/socialIcons/redditSmall.png'; ?>" alt="" />Reddit</a></li>
							<?php } ?>
							<?php if (get_option('of_flickr') != '') { ?>
								<li><a href="<?php echo get_option('of_flickr'). '" '. $social_new_tab; ?>><img src="<?php echo bloginfo('template_directory') . '/img/socialIcons/flickrSmall.png'; ?>" alt="" />Flickr</a></li>
							<?php } ?>
							<?php if (get_option('of_linkedin') != '') { ?>
								<li><a href="<?php echo get_option('of_linkedin'). '" '. $social_new_tab; ?>><img src="<?php echo bloginfo('template_directory') . '/img/socialIcons/linkedinSmall.png'; ?>" alt="" />LinkedIn</a></li>
							<?php } ?>
							<?php if (get_option('of_lastfm') != '') { ?>
								<li><a href="<?php echo get_option('of_lastfm'). '" '. $social_new_tab; ?>><img src="<?php echo bloginfo('template_directory') . '/img/socialIcons/lastfmSmall.png'; ?>" alt="" />Last.fm</a></li>
							<?php } ?>
							<?php if (get_option('of_digg') != '') { ?>
								<li><a href="<?php echo get_option('of_digg'). '" '. $social_new_tab; ?>><img src="<?php echo bloginfo('template_directory') . '/img/socialIcons/diggSmall.png'; ?>" alt="" />Digg</a></li>
							<?php } ?>
						</ul>
					</div> <!-- /.pageMiddle -->
					<span class="pageBottom"></span>
					<span class="pageShadow"></span>
				</aside> <!-- /.pageBlock -->
			<?php } ?>
			
		</div> <!-- /.containerInner -->
	</div> <!-- /.container -->
</aside>

<?php endif; ?>