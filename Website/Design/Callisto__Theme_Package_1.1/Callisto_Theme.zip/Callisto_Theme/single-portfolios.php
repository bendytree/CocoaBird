<?php get_header(); ?>

<section>
	<header class="titleSpace">
		<div class="container group">
			<h1><?php the_title(); ?></h1>
			<?php if (function_exists('breadcrumbs')) breadcrumbs(); ?>
		</div> <!-- /.container -->
	</header> <!-- /.titleSpace -->
		
	<div class="container group">
		<div class="containerInner group">
			<?php if (get_option('of_portfolio_item_sidebar') == 'true') echo '<div class="pageHolder group">'; ?>
			
				<div class="pageBlock <?php if (get_option('of_portfolio_item_sidebar') == 'true') echo 'boxTwoThirds'; ?>">
					<span class="pageTop"></span>
					<div class="pageMiddle group">
					
						<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
						
							<?php if (get_option('of_portfolio_meta_display') == 'true' || get_option('of_portfolio_meta_display') == '') { ?>
								<footer class="cal_post_meta portfolioPostMeta group">
									<ul>
										<li class="metaDate"><time datetime="<?php the_time('c'); ?>" pubdate><?php the_time('l, F jS, Y'); ?></time></li>
										<?php
											echo '<li class="metaCat">';
											echo the_category(', ') . '</li>';
										if (has_tag()) {
											echo '<li class="metaTag">';
											echo the_tags('', ', ') . '</li>';
										} ?>
									</ul>
								</footer> <!-- /.cal_post_meta -->
							<?php } ?>
								
							<?php the_content(); ?>
						<?php endwhile; ?>
						
					</div> <!-- /.pageMiddle -->
					<span class="pageBottom"></span>
					<span class="pageShadow"></span>
				</div> <!-- /.pageBlock -->
				
			<?php if (get_option('of_portfolio_item_sidebar') == 'true') { echo '</div> <!-- /.pageHolder -->'; get_sidebar(); } ?>
		</div> <!-- /.containerInner -->
	</div> <!-- /.container -->
</section>

<?php get_footer(); ?>