<?php get_header(); ?>

<article>
	<header class="titleSpace">
		<div class="container group">
			<h1><?php the_title(); ?></h1>
			<?php if (function_exists('breadcrumbs')) breadcrumbs(); ?>
		</div> <!-- /.container -->
	</header> <!-- /.titleSpace -->
		
	<div class="container group">
		<div class="containerInner group">
			<?php if (get_option('of_blog_item_sidebar') == 'true') echo '<div class="pageHolder group">'; ?>
			
				<div class="pageBlock <?php if (get_option('of_blog_item_sidebar') == 'true') echo 'boxTwoThirds'; ?>">
					<span class="pageTop"></span>
					<div class="pageMiddle group">
					
						<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
						
							<?php if (get_option('of_blog_meta_display') == 'true' || get_option('of_blog_meta_display') == '') { ?>
								<footer class="cal_post_meta blogPostMeta group">
									<ul>
										<li class="metaDate"><time datetime="<?php the_time('c'); ?>" pubdate><?php the_time('l, F jS, Y'); ?></time></li>
										<?php
											echo '<li class="metaCat">';
											echo the_category(', ') . '</li>';
										?>
									</ul>
									<ul>
										<?php if (get_comments_number() != 0) {
											echo '<li class="metaComment"><a href="';
											echo comments_link() . '">';
											printf( _n( '1 Comment', '%1$s Comments', get_comments_number() ), number_format_i18n( get_comments_number() ));
											echo '</a></li>';
										} if (has_tag()) {
											echo '<li class="metaTag">';
											echo the_tags('', ', ') . '</li>';
										} ?>
									</ul>
								</footer> <!-- /.cal_post_meta -->
							<?php } ?>
								
							<?php the_content(); ?>
						<?php endwhile; ?>
						
					</div> <!-- /.pageMiddle -->
					<span class="pageBottom"></span>
					<span class="pageShadow"></span>
				</div> <!-- /.pageBlock -->
				
			<?php if (get_option('of_blog_item_sidebar') == 'true') { echo '</div> <!-- /.pageHolder -->'; get_sidebar(); } ?>
		</div> <!-- /.containerInner -->
	</div> <!-- /.container -->

	<?php comments_template(); ?>
</article>

<?php get_footer(); ?>