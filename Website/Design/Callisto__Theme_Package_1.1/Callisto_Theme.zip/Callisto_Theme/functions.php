<?php
/*-----------------------------------------------------------------------------------*/
/* Options Framework Functions
/*-----------------------------------------------------------------------------------*/

/* Set the file path based on whether the Options Framework is in a parent theme or child theme */

if ( STYLESHEETPATH == TEMPLATEPATH ) {
	define('OF_FILEPATH', TEMPLATEPATH);
	define('OF_DIRECTORY', get_bloginfo('template_directory'));
} else {
	define('OF_FILEPATH', STYLESHEETPATH);
	define('OF_DIRECTORY', get_bloginfo('stylesheet_directory'));
}

/* These files build out the options interface.  Likely won't need to edit these. */

require_once (OF_FILEPATH . '/admin/admin-functions.php');		// Custom functions and plugins
require_once (OF_FILEPATH . '/admin/admin-interface.php');		// Admin Interfaces (options,framework, seo)

/* These files build out the theme specific options and associated functions. */

require_once (OF_FILEPATH . '/admin/theme-options.php'); 		// Options panel settings and custom settings
require_once (OF_FILEPATH . '/admin/theme-functions.php'); 	// Theme actions based on options settings


/*-----------------------------------------------------------------------------------*/
/* Enqueue Styles & Scripts
/*-----------------------------------------------------------------------------------*/

require_once (OF_FILEPATH . '/admin/styles-scripts.php');


/*-----------------------------------------------------------------------------------*/
/* Thumbnail Functions
/*-----------------------------------------------------------------------------------*/

if ( function_exists( 'add_theme_support' ) ) {
	add_theme_support( 'post-thumbnails' );
        set_post_thumbnail_size(250, 117, true); // default Post Thumbnail dimensions   
}

if ( function_exists( 'add_image_size' ) ) {
	$arg_a = get_option('of_featured_area_height');
	$arg_b = round($arg_a / 5.77380952);
	add_image_size( 'callisto_small', 250, 117, true);
	add_image_size( 'callisto_medium', 416, 192, true );
	add_image_size( 'callisto_large', 582, 270, true );
	add_image_size( 'slider_image', 970, $arg_a, true );
	add_image_size( 'slider_thumb', 168, $arg_b, true );
}


/*-----------------------------------------------------------------------------------*/
/* Menu Functions
/*-----------------------------------------------------------------------------------*/

function register_my_menu() {
	register_nav_menu( 'primary-menu', __( 'Primary Menu' ) );
}

add_action( 'init', 'register_my_menu' );


/*-----------------------------------------------------------------------------------*/
/* Edit 'Read More' Tag
/*-----------------------------------------------------------------------------------*/

function custom_excerpt_more( $more ) {
	return ' (&hellip;)';
}
add_filter( 'excerpt_more', 'custom_excerpt_more' );


/*-----------------------------------------------------------------------------------*/
/* Custom Post Type Functions
/*-----------------------------------------------------------------------------------*/

function create_post_type() {
	
	if (get_option('of_portfolio_name') != '') { 
		$portfolio_name = get_option('of_portfolio_name');
	} else {
		$portfolio_name = 'Portfolio';
	}
	$clean_portfolio_name = preg_replace('/[^a-z0-9]+/i', '-', strtolower($portfolio_name));
	
	register_post_type( 'portfolios',
		array(
		'labels' => array('name' => __( $portfolio_name )),
		'public' => true,
		'rewrite' => array('slug' => $clean_portfolio_name . '/items' ),
		'supports' => array('title','editor','thumbnail', 'excerpt', 'revisions'),
		'taxonomies' => array('category', 'post_tag')
		)
	);
}

add_action( 'init', 'create_post_type' );


function my_get_posts( $query ) {
        
    if ( is_category() && false == $query->query_vars['suppress_filters'] || is_tag() && false == $query->query_vars['suppress_filters'] )
        $query->set( 'post_type', array( 'post', 'portfolios' ) );

    return $query;
}

add_filter( 'pre_get_posts', 'my_get_posts' );


function portfolios_icons() {
    ?>
    <style type="text/css" media="screen">
        #menu-posts-portfolios .wp-menu-image {
            background: url(<?php bloginfo('template_url') ?>/admin/images/portfolio-icon.png) no-repeat 6px 6px !important;
        }
    #menu-posts-portfolios:hover .wp-menu-image, #menu-posts-portfolio.wp-has-current-submenu .wp-menu-image {
            background-position:6px -16px !important;
        }
    #icon-edit.icon32-posts-portfolios {background: url(<?php bloginfo('template_url') ?>/admin/images/portfolio-32x32.png) no-repeat;}
    </style>
<?php }
 
add_action( 'admin_head', 'portfolios_icons' );


/*-----------------------------------------------------------------------------------*/
/* Navigation Functions
/*-----------------------------------------------------------------------------------*/

require_once (OF_FILEPATH . '/includes/navigation.php');


/*-----------------------------------------------------------------------------------*/
/* Comments
/*-----------------------------------------------------------------------------------*/

require_once (OF_FILEPATH . '/includes/comments.php');


/*-----------------------------------------------------------------------------------*/
/* Breadcrumbs
/*-----------------------------------------------------------------------------------*/

require_once (OF_FILEPATH . '/includes/breadcrumbs.php');


/*-----------------------------------------------------------------------------------*/
/* Widgetised Footer & Sidebar
/*-----------------------------------------------------------------------------------*/

if (function_exists('register_sidebar')) {
	register_sidebar(array(
		'name' => 'Sidebar',
		'id'   => 'sidebar-widgetized-area',
		'description'   => 'This is the widgetized sidebar area.',
		'before_widget' => '<div id="%1$s" class="widget %2$s group">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>'
	));
}

if (function_exists('register_sidebar') && get_option('of_footer_widget_count') == 'four' || get_option('of_footer_widget_count') == '') {
	register_sidebar(array(
		'name' => 'Footer - 4 Widgets',
		'id'   => 'footer-widgetized-area',
		'description'   => 'This is the 4-widget footer. You can switch to a 3-widget footer in the General Settings tab of the Options Panel.',
		'before_widget' => '<div id="%1$s" class="widget %2$s footerOneFourth group">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>'
	));
}

if (function_exists('register_sidebar') && get_option('of_footer_widget_count') == 'three') {
	register_sidebar(array(
		'name' => 'Footer - 3 Widgets',
		'id'   => 'footer-widgetized-area',
		'description'   => 'This is the 3-widget footer. You can switch to a 4-widget footer in the General Settings tab of the Options Panel.',
		'before_widget' => '<div id="%1$s" class="widget %2$s footerOneThird group">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>'
	));
}


/*-----------------------------------------------------------------------------------*/
/* Widgets
/*-----------------------------------------------------------------------------------*/

require_once (OF_FILEPATH . '/admin/widgets/flickr-widget.php');
require_once (OF_FILEPATH . '/admin/widgets/twitter-widget.php');
require_once (OF_FILEPATH . '/admin/widgets/sidebar-advert-widget.php');
require_once (OF_FILEPATH . '/admin/widgets/sidebar-google-map-widget.php');


/*-----------------------------------------------------------------------------------*/
/* Enable Shortcodes in Sidebar/Footer
/*-----------------------------------------------------------------------------------*/

add_filter('widget_text', 'do_shortcode');


/*-----------------------------------------------------------------------------------*/
/* Alter Excerpt Length
/*-----------------------------------------------------------------------------------*/

function new_excerpt_length($length) {
	return 18;
}
add_filter('excerpt_length', 'new_excerpt_length');


/*-----------------------------------------------------------------------------------*/
/* Blog Pagination
/*-----------------------------------------------------------------------------------*/

require_once (OF_FILEPATH . '/includes/pagination.php');


/*-----------------------------------------------------------------------------------*/
/* Visual Editor CSS
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists('shortcode_css') ) {
	function shortcode_css($wp) {
		$wp .= ',' . get_bloginfo('template_directory') . '/admin/shortcodes/css/custom_tinymce.css';
	return $wp;
	}
}
add_filter( 'mce_css', 'shortcode_css' );


/*-----------------------------------------------------------------------------------*/
/* Add Category & Tag Support to Pages
/*-----------------------------------------------------------------------------------*/

function add_category_box_on_page(){
    add_meta_box('categorydiv', __('Categories'), 'post_categories_meta_box', 'page', 'side', 'low');
    add_meta_box('tagsdiv-post_tag', __('Page Tags'), 'post_tags_meta_box', 'page', 'side', 'low');
    add_action('save_post', 'add_cats_to_pages');
}
 
add_action('admin_menu', 'add_category_box_on_page');

function add_cats_to_pages( $post_id ) {
 
    $wpnj_post_type = $_POST['post_type'];
 
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ){
 
    }else{
        // Check permissions
        if ( 'page' == $wpnj_post_type ) {
            if ( current_user_can( 'edit_page', $post_id ) ){
 
                $wpnj_post_cats = array();
 
                foreach($_REQUEST['post_category'] as $key=>$val){
                    $wpnj_post_cats[] = $val;
                }
                wp_set_post_categories( $post_id, $wpnj_post_cats );
            }
        }
    }
}


/*-----------------------------------------------------------------------------------*/
/* Dashboard Theme Update Notifer
/* Original code courtesy of João Araújo of Unisphere Design - http://themeforest.net/user/unisphere
/*-----------------------------------------------------------------------------------*/

function update_notifier_menu() {  
	$xml = get_latest_theme_version(21600); // This tells the function to cache the remote call for 21600 seconds (6 hours)
	$theme_data = get_theme_data(TEMPLATEPATH . '/style.css'); // Get theme data from style.css (current version is what we want)
	
	if(version_compare($theme_data['Version'], $xml->latest) == -1) {
		add_dashboard_page( $theme_data['Name'] . ' Theme Updates', $theme_data['Name'] . '<span class="update-plugins count-1"><span class="update-count">New Updates</span></span>', 'administrator', strtolower($theme_data['Name']) . '-updates', update_notifier);
	}
}  

add_action('admin_menu', 'update_notifier_menu');

function update_notifier() { 
	$xml = get_latest_theme_version(21600); // This tells the function to cache the remote call for 21600 seconds (6 hours)
	$theme_data = get_theme_data(TEMPLATEPATH . '/style.css'); // Get theme data from style.css (current version is what we want) ?>
	
	<style>
		.update-nag {display: none;}
		#instructions {max-width: 800px;}
		h3.title {margin: 30px 0 0 0; padding: 30px 0 0 0; border-top: 1px solid #ddd;}
	</style>

	<div class="wrap">
	
		<div id="icon-tools" class="icon32"></div>
		<h2><?php echo $theme_data['Name'] . ' Theme Updates'; ?></h2>
	    <div id="message" class="updated below-h2"><p><strong>There is a new version of the <?php echo $theme_data['Name']; ?> theme available.</strong> You have version <?php echo $theme_data['Version']; ?> installed. Update to version <?php echo $xml->latest; ?>.</p></div>
        
        <img style="float: left; margin: 0 20px 20px 0; border: 1px solid #ddd;" src="<?php echo get_bloginfo( 'template_url' ) . '/screenshot.png'; ?>" />
        
        <div id="instructions" style="max-width: 800px;">
            <h3>Update Download and Instructions</h3>
            <p><strong>Please note:</strong> make a <strong>backup</strong> of the Theme inside your WordPress installation folder <strong>/wp-content/themes/<?php echo strtolower($theme_data['Name']); ?>/</strong></p>
            <p>To update the Theme, login to <a href="http://www.themeforest.net/">ThemeForest</a>, head over to your <strong>downloads</strong> section and re-download the theme like you did when you bought it.</p>
            <p>Extract the zip's contents, look for the extracted theme folder, and after you have all the new files upload them using FTP to the <strong>/wp-content/themes/<?php echo strtolower($theme_data['Name']); ?>/</strong> folder overwriting the old ones (this is why it's important to backup any changes you've made to the theme files).</p>
            <p>If you didn't make any changes to the theme files, you are free to overwrite them with the new ones without the risk of losing theme settings, pages, posts, etc, and backwards compatibility is guaranteed.</p>
        </div>
        
            <div class="clear"></div>
	    
	    <h3 class="title">Changelog</h3>
	    <?php echo $xml->changelog; ?>

	</div>
    
<?php } 

// This function retrieves a remote xml file on my server to see if there's a new update 
// For performance reasons this function caches the xml content in the database for XX seconds ($interval variable)
function get_latest_theme_version($interval) {
	// remote xml file location
	$notifier_file_url = 'http://icarusindustries.com/theme-changelogs/callisto/notifier.xml';
	
	$db_cache_field = 'icarus-notifier-cache';
	$db_cache_field_last_updated = 'icarus-notifier-last-updated';
	$last = get_option( $db_cache_field_last_updated );
	$now = time();
	// check the cache
	if ( !$last || (( $now - $last ) > $interval) ) {
		// cache doesn't exist, or is old, so refresh it
		if( function_exists('curl_init') ) { // if cURL is available, use it...
			$ch = curl_init($notifier_file_url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_TIMEOUT, 10);
			$cache = curl_exec($ch);
			curl_close($ch);
		} else {
			$cache = file_get_contents($notifier_file_url); // ...if not, use the common file_get_contents()
		}
		
		if ($cache) {			
			// we got good results
			update_option( $db_cache_field, $cache );
			update_option( $db_cache_field_last_updated, time() );			
		}
		// read from the cache file
		$notifier_data = get_option( $db_cache_field );
	}
	else {
		// cache file is fresh enough, so read from it
		$notifier_data = get_option( $db_cache_field );
	}
	
	$xml = simplexml_load_string($notifier_data); 
	
	return $xml;
}

function update_notifier_bar_menu() {
	global $wp_admin_bar, $wpdb;

	if ( !is_super_admin() || !is_admin_bar_showing() )
	return;
	
	$xml = get_latest_theme_version(21600); // This tells the function to cache the remote call for 21600 seconds (6 hours)
	$theme_data = get_theme_data(TEMPLATEPATH . '/style.css'); // Get theme data from style.css (current version is what we want)
	
	if(version_compare($theme_data['Version'], $xml->latest) == -1) {
		$wp_admin_bar->add_menu( array( 'id' => 'update_notifier', 'title' => '<span>' . $theme_data['Name'] . ' <span id="ab-updates">New Updates</span></span>', 'href' => get_admin_url() . 'index.php?page=' . strtolower($theme_data['Name']) . '-updates' ) );
	}
}

add_action( 'admin_bar_menu', 'update_notifier_bar_menu', 1000 );
?>