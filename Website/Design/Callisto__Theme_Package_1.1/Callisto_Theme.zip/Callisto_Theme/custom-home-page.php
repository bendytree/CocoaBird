<?php
/*
Template Name: Home
*/
get_header( 'tall' ); ?>

<section class="container group">

	<?php if (get_option('of_home_featured') == 'slider') {
			include(TEMPLATEPATH . '/includes/nivo-slider.php');
		} elseif (get_option('of_home_featured') == 'accordion') {
			include(TEMPLATEPATH . '/includes/accordion.php');
		} elseif (get_option('of_home_featured') == 'single_post') {
			include(TEMPLATEPATH . '/includes/featured-single-post.php');
		} 
	?>
	<noscript>
		<?php include(TEMPLATEPATH . '/includes/featured-single-post.php'); ?>
	</noscript>
	
</section> <!-- /.container -->

<div class="subtitleSpace">
	<div class="container">
		<h2><?php echo stripslashes(get_option('of_home_message')); ?></h2>
	</div> <!-- /.container -->
</div> <!-- /.titleSpace -->
	
<section>
	<div class="container group">
		<div class="containerInner group">
			<?php if (get_option('of_home_content') == 'custom_content' || get_option('of_home_content') == 'both') { ?>
			
				<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
					<?php the_content(); ?>
					<div style="clear:both;"></div>
				<?php endwhile; ?>
				
			<?php } ?>
			
			<?php if (get_option('of_home_content') == 'blog_posts' || get_option('of_home_content') == 'both') { ?>
				
				<?php if (get_option('of_home_sidebar') == 'true') echo '<div class="pageHolder group">'; ?>
					<?php if (get_option('of_home_columns') == 'two' || get_option('of_home_columns') == 'three') echo '<div class="masonry group">'; ?>
						
						<?php
						$temp = $wp_query;
						$wp_query = null;
						$wp_query = new WP_Query('posts_per_page='.get_option("of_home_posts_shown").'&cat=-'.get_cat_id(get_option('of_featured_category')));
						$wp_query->query;
						while ($wp_query->have_posts()) : $wp_query->the_post(); ?>
					
						<article class="pageBlock group <?php if (get_option('of_home_columns') == 'one' && get_option('of_home_sidebar') == 'false') echo ''; elseif (get_option('of_home_columns') == 'one' && get_option('of_home_sidebar') == 'true') echo 'boxTwoThirds';  elseif  (get_option('of_home_columns') == 'two' && get_option('of_home_sidebar') == 'false') echo 'boxOneHalf';  else  echo 'boxOneThird'; ?>">
							<span class="pageTop"></span>
							<div class="pageMiddle group">
			
								<?php if (get_option('of_home_columns') == 'one') $thumbSize = 'large'; elseif (get_option('of_home_columns') == 'two' && get_option('of_home_sidebar') == 'false') $thumbSize = 'medium'; else $thumbSize = 'small'; ?>
								<?php if (get_option('of_home_columns') == 'one' && get_option('of_home_sidebar') == 'false') $largeClass = 'twoThirds first'; ?>
								<?php if ( has_post_thumbnail() ) {
									echo '<a href="';
									echo the_permalink();
									echo '" class="preloadHolder '.$largeClass.'">';
								    the_post_thumbnail('callisto_'.$thumbSize, array('class' => 'postThumb preloadMe'));
								    echo '</a>';
								} ?>
								
								<?php if  (get_option('of_home_columns') == 'one' && get_option('of_home_sidebar') == 'false') echo '<div class="portfolioInfo oneThird">';  ?>
									<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
									
									<?php if (get_option('of_blog_meta_display') == 'true' || get_option('of_blog_meta_display') == '') { ?>
										<footer class="cal_post_meta">
											<ul>
												<li class="metaDate"><?php the_time('l, F jS, Y'); ?></li>
												<?php
													echo '<li class="metaCat">';
													echo the_category(', ') . '</li>';
												if (has_tag()) {
													echo '<li class="metaTag">';
													echo the_tags('', ', ') . '</li>';
												} if (get_comments_number() != 0) {
													echo '<li class="metaComment"><a href="';
													echo comments_link() . '">';
													printf( _n( '1 Comment', '%1$s Comments', get_comments_number() ), number_format_i18n( get_comments_number() ));
													echo '</a></li>';
												} ?>
											</ul>
										</footer> <!-- /.cal_post_meta -->
									<?php } ?>
									
									<?php the_excerpt(); ?>
									<a href="<?php the_permalink(); ?>" class="button <?php if  (get_option('of_home_columns') == 'two' && get_option('of_home_sidebar') == 'true' || get_option('of_home_columns') == 'three') echo 'width100'; ?>">
										<div>
											<p>Read More</p>
										</div>
									</a>
								<?php if (get_option('of_home_columns') == 'one' && get_option('of_home_sidebar') == 'false') echo '</div> <!-- /.portfolioInfo -->';  ?>
							</div> <!-- /.pageMiddle -->
							<span class="pageBottom"></span>
							<span class="pageShadow"></span>
						</article> <!-- /.pageBlock -->
						
						<?php endwhile; ?>
					
					<?php if  (get_option('of_home_columns') == 'two' || get_option('of_home_columns') == 'three') echo '</div> <!-- /.masonry -->';  ?>
				<?php if  (get_option('of_home_sidebar') == 'true') echo '</div> <!-- /.pageHolder -->';  ?>
				<?php if (get_option('of_home_sidebar') == 'true') get_sidebar(); ?>	
				<?php $wp_query = null; $wp_query = $temp;?>
				
			<?php } ?>
				
		</div> <!-- /.containerInner -->
	</div> <!-- /.container -->
</section>

<?php get_footer(); ?>