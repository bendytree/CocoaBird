<!DOCTYPE html>
<!--[if IE 7 ]>    <html class="ie7" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 8 ]>    <html class="ie8" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 9 ]>    <html class="ie9" <?php language_attributes(); ?>> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html <?php language_attributes(); ?>> <!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<title><?php 
				global $page, $paged;
				wp_title( '|', true, 'right' );
				bloginfo( 'name' );
				$site_description = get_bloginfo( 'description', 'display' );
				if ( $site_description && ( is_page_template('custom-home-page.php') || is_front_page() ) )
				echo " | $site_description"; 
			?>	
	</title>
	
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
	<style>
		.preload, #slider, .kwicks, .kwicks li, .kwicksShadow { height: <?php echo get_option('of_featured_area_height') . 'px;' ?> }
		#myslidemenu { margin: <?php echo round(get_option('of_header_logo_height') / 2) . 'px' . ' 0;' ?> }
		.header { height: <?php echo round(get_option('of_header_logo_height') + (get_option('of_featured_area_height') / 2) + 100) . 'px' ?>; margin-bottom: <?php echo '-' . round(get_option('of_featured_area_height') / 2 + 3) . 'px;' ?> }
		.footerLower .container p { line-height: <?php echo get_option('of_footer_logo_height') . 'px;' ?> }
		#slider-wrapper { padding: 0 0 <?php echo round((get_option('of_featured_area_height') / 5.77380952)) + 83; ?>px 0; }
		.nivo-directionNav a { top: <?php $a = 100 * 30 / get_option('of_featured_area_height'); echo (100 - $a) / 2 . '%;'; ?>}
		#slider .nivo-controlNav { bottom: -<?php echo round((get_option('of_featured_area_height') / 5.77380952)) + 44; ?>px; }
		#slider .nivo-controlNav .nivo-control .zoom { height: <?php echo round((get_option('of_featured_area_height') / 5.77380952)); ?>px; }
		<?php if (get_option('of_home_slider_caption') == 'false') echo '#slider .nivo-caption, .kwicksCaption, #image-wrapper .nivo-caption { display:none!important; }'; ?>
		<?php if (get_option('of_slider_caption_alignment') == 'left') echo '#slider .nivo-caption { width: auto; padding: 5px 35px 19px; -moz-border-radius: 0 8px 0 0; -webkit-border-radius: 0 8px 0 0; border-radius: 0 8px 0 0; } #slider .nivo-caption-shadow { display: none; } ';?>
		<?php if (get_option('of_slider_caption_alignment') == 'right') echo '#slider .nivo-caption { left: auto; right: 0px; width: auto; padding: 5px 35px 19px; -moz-border-radius: 8px 0 0 0; -webkit-border-radius: 8px 0 0 0; border-radius: 8px 0 0 0; } #slider .nivo-caption-shadow { display: none; } ';?>
		<?php if (get_option('of_slider_active_thumb_border_color') != '') echo '#slider .nivo-controlNav .nivo-control.active { background: '.get_option("of_slider_active_thumb_border_color").'; }'; ?>
	</style>
	
	<link href="<?php echo get_template_directory_uri() . '/styles/print.css'; ?>" rel="stylesheet" type="text/css" media="print" />
	
	<noscript>
		<style>
			#slider-wrapper, #kwicks-wrapper { display: none; }
			.preloadMe, .flickr_badge_image img, .tab_content, .toggle_container, .avatar { display: block; }
			pre, code, kbd, samp { overflow: auto; }
			.menu li:hover > ul { visibility: visible; }
			.menu li > ul > li ul { margin: -40px 0 0 192px; }
			.tab_content { padding-bottom: 1.6em; margin-bottom: 1.6em; border-bottom: 1px solid #eee; } .tab_content:last-child { margin-bottom: 0; }
		</style>
	</noscript>
	
	<script>
		var arrowimages={down:['downarrowclass', '<?php bloginfo('template_url'); ?>/img/arrowDown.png'], right:['rightarrowclass', '<?php bloginfo('template_url'); ?>/img/arrowRight.png']}
	</script>
	
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	
	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri() . '/js/html5shiv.js'; ?>"></script>
	<![endif]-->
	
	<?php wp_head(); ?>
	
	<?php if (get_option('of_font_method') == 'cufon' || get_option('of_font_method') == '') { ?>
		<!--[if gte IE 9]><!-->
		  <script>
		  	Cufon.replace('.menu li a', {
		  		textShadow: '0 -1px #000',
		  		color: '-linear-gradient(#fff, #cfcfcf)'
		  	});
			Cufon.replace('.captionHeader', {
				textShadow: '0 -1px #000',
				color: '-linear-gradient(#fff, #cfcfcf)'
			});
		  </script>
		<!--<![endif]-->
	<?php } ?>
</head>

<body <?php body_class(); ?> <?php if (strpos($post->post_content, 'prettyprint') !== false) echo 'onload="prettyPrint()"'; ?>>
	<header class="header group">
		<div class="lightOverlay">
			<div class="headerInner group">
				<div class="topBar group">
					<div class="container group">
						<?php if (get_option('of_header_rss_link') == 'true' || get_option('of_header_rss_link') == '') { ?>
							<a href="<?php bloginfo('rss2_url'); ?>"><?php if (get_option('of_trans_rss_text') != '') echo stripslashes(get_option('of_trans_rss_text')); else echo 'Subscribe via RSS'; ?><img src="<?php echo get_template_directory_uri() . '/img/rssIcon.png'; ?>" alt="RSS" title="RSS" /></a>
						<?php } ?>
						<?php get_search_form(); ?>
					</div> <!-- /.container -->
				</div> <!-- /.topBar -->
			
				<div class="container group">
					<a href="<?php bloginfo('url'); ?>" class="logo">
						<img src="<?php echo get_option('of_header_logo'); ?>" alt="Home" title="Home" />
					</a>
					
					<nav role="navigation" id="myslidemenu" class="jqueryslidemenu group">
						<?php wp_nav_menu( array(
						 'theme_location' => 'primary-menu',
						 'menu' => 'primary-menu',
						 'container' => false,
						 'walker' => new description_walker())
						 ); ?>
					</nav> <!-- /#myslidemenu -->
					<script>jQuery('.menu > li:not(".menu > li:last-child")').after('<span class="navDivider"></span>');</script>
				</div> <!-- /.container -->
			</div> <!-- /.headerInner -->
		</div> <!-- /.lightOverlay -->
	</header> <!-- /.header -->