<?php
function breadcrumbs() {

	if (get_option('of_trans_breadcrumb_home_link') != '') $home = stripslashes(get_option('of_trans_breadcrumb_home_link')); else $home = 'Home';
	$delimiter = '&raquo;';
	$before = '<span class="current">'; // tag before the current crumb
	$after = '</span>'; // tag after the current crumb
	
	if ( !is_page_template('custom-home-page.php') && !is_front_page() || is_paged() ) {
		echo '<nav class="breadcrumbs"><ul>';
		global $post;
		$homeLink = get_bloginfo('url');
		echo '<li><a href="' . $homeLink . '">' . $home . '</a> ' . $delimiter . ' </li>';
	
		/*------------------------------------------------*/
		  /* Copyright 2010 Jordon Bedwell
		  /* MIT Licensed - Example Code
		  /* An example of "faster" category breadcrumbs
		  /*------------------------------------------------*/
		  if(is_category( )) {
		    global $cat;
		    $categories = substr(get_category_parents($cat, true, '_split_'), 0, -7);
		    if($categories = explode('_split_', $categories)) {
		      $total = (count($categories) - 1);
		      $current = 0;
		      foreach($categories as $category) {
		        if($current == $total) {
		          echo '<li>' . $before . $category . $after . '</li>';
		        } else { echo '<li>' . $category . ' &#187; </li>'; } ($current++);
		      }
		    } else { echo '<li>' . $before . $categories . $after . '</li>'; }
		  }
		
		elseif ( is_day() ) {
			echo '<li><a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' </li>';
			echo '<li><a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' </li>';
			echo '<li>'.$before . get_the_time('Y') . $after.'</li>';
		}
		
		elseif ( is_month() ) {
			echo '<li><a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' </li>';
			echo '<li>'.$before . get_the_time('F') . $after.'</li>';
		}
		
		elseif ( is_year() ) {
			echo '<li>'.$before . get_the_time('Y') . $after.'</li>';
		}
		
		elseif ( is_single() && !is_attachment() ) {
			if ( get_post_type() != 'post' ) {	
				$post_type = get_post_type_object(get_post_type());
				$slug = $post_type->rewrite;
				echo '<li><a href="' . $homeLink . '/' . substr($slug['slug'], 0, -6) . '/">' . $post_type->labels->singular_name . '</a> ' . $delimiter . ' </li>';
				echo '<li>'.$before . get_the_title() . $after.'</li>';
			}
			else {
				$cat = get_the_category(); $cat = $cat[0];
				echo '<a href="' . get_permalink(get_option('page_for_posts')) . '">' . get_the_title(get_option('page_for_posts')) . '</a>' . ' ' . $delimiter . ' ';
				//echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
				echo '<li>'.$before . get_the_title() . $after.'</li>';
			}
		}
		
		elseif ( !is_single() && !is_page() && get_post_type() != 'post' ) {
			$post_type = get_post_type_object(get_post_type());
			echo '<li>'.$before . $post_type->labels->singular_name . $after.'</li>';
		}
		
		elseif ( is_attachment() ) {
			$parent = get_post($post->post_parent);
			$cat = get_the_category($parent->ID); $cat = $cat[0];
			echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
			echo '<li><a href="' . get_permalink($parent) . '">' . $parent->post_title . '</a> ' . $delimiter . ' </li>';
			echo '<li>'.$before . get_the_title() . $after.'</li>';
		}
		
		elseif ( is_page() && !$post->post_parent && !get_query_var('paged') ) {
			echo '<li>'.$before . get_the_title() . $after.'</li>';
		}
		
		elseif ( is_page() && !$post->post_parent && get_query_var('paged') ) {
			echo '<a href="';
			echo the_permalink() . '">';
			echo $before . get_the_title() . $after;
			echo '</a>';
		}
		
		elseif ( is_home() && !$post->post_parent && !get_query_var('paged')) {
			echo '<li>'.$before . get_the_title(get_option('page_for_posts')) . $after.'</li>';
		}
		
		elseif ( is_home() && get_query_var('paged') ) {
			echo '<a href="';
			echo get_permalink(get_option('page_for_posts')) . '">';
			echo $before . get_the_title(get_option('page_for_posts')) . $after;
			echo '</a>';
		}
		
		elseif ( is_page() && $post->post_parent ) {
			$parent_id  = $post->post_parent;
			$breadcrumbs = array();
			while ($parent_id) {
			$page = get_page($parent_id);
			$breadcrumbs[] = '<li><a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a></li>';
			$parent_id  = $page->post_parent;
		}
		
		$breadcrumbs = array_reverse($breadcrumbs);
			foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
			echo '<li>'.$before . get_the_title() . $after.'</li>';
		}
		
		elseif ( is_search() ) {
			echo '<li>'.$before . 'Error 404' . $after.'</li>';
		}
		
		elseif ( is_tag() ) {
			echo '<li>'.$before . 'Posts tagged "' . single_tag_title('', false) . '"' . $after.'</li>';
		}
		
		elseif ( is_author() ) {
			global $author;
			$userdata = get_userdata($author);
			echo '<li>'.$before . 'Articles posted by ' . $userdata->display_name . $after.'</li>';
		}
		
		elseif ( is_404() ) {
			echo '<li>'.$before . 'Error 404' . $after.'</li>';
		}
		
		if ( get_query_var('paged') ) {
			if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
			echo __(' ' .$delimiter. ' Page') . ' ' . get_query_var('paged');
			if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
		}
		
		echo '</ul></nav>';
	
	}
}