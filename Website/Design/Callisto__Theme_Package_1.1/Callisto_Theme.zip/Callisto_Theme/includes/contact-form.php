<?php 
//If the form is submitted
if(isset($_POST['submitted'])) {

	//Check to see if the honeypot captcha field was filled in
	if(trim($_POST['checking']) !== '') {
		$captchaError = true;
	} else {
	
		//Check to make sure that the name field is not empty
		if(trim($_POST['contactName']) === '') {
			$nameError = 'Please enter your name.';
			$hasError = true;
		} else {
			$name = trim($_POST['contactName']);
		}
		
		//Check to make sure sure that a valid email address is submitted
		if(trim($_POST['email']) === '')  {
			$emailError = 'Please enter your email address.';
			$hasError = true;
		} else if (!eregi("^[A-Z0-9._%-]+@[A-Z0-9._%-]+\.[A-Z]{2,4}$", trim($_POST['email']))) {
			$emailError = 'You entered an invalid email address.';
			$hasError = true;
		} else {
			$email = trim($_POST['email']);
		}
		
		//Check to make sure that the name field is not empty
		if(trim($_POST['subject']) === '') {
			$contactSubjectError = 'Please enter a subject.';
			$contactSubjectError = true;
		} else {
			$contactSubject = trim($_POST['subject']);
		}
			
		//Check to make sure message has been entered	
		if(trim($_POST['comments']) === '') {
			$commentError = 'Please enter your message';
			$hasError = true;
		} else {
			if(function_exists('stripslashes')) {
				$comments = stripslashes(trim($_POST['comments']));
			} else {
				$comments = trim($_POST['comments']);
			}
		}
			
		//If there is no error, send the email
		if(!isset($hasError)) {

			$emailTo = get_option('of_recipient_email');
			$subject = $contactSubject;
			$body = "Name: $name \n\nEmail: $email \n\nMessage: $comments";
			$headers = 'From: '. $name . "\r\n" . 'Reply-To: ' . $email;
			
			mail($emailTo, $subject, $body, $headers);

			$emailSent = true;

		}
	}
} ?>

<?php if(isset($emailSent) && $emailSent == true) { ?>

	<div class="alertBox green formSuccess">
		<div>
			<p>Your message was successfully sent.</p>
		</div>
	</div> <!-- /.alertBox -->

<?php } else { ?>
	
		<form class="group" action="<?php the_permalink(); ?>" id="contactForm" class="contactForm" method="post">
			<fieldset>
				<label for="contactName">Name<span class="required">&#42;</span></label>
				<input type="text" name="contactName" id="contactName" value="<?php if(isset($_POST['contactName'])) echo $_POST['contactName'];?>" class="requiredField" required/>
				<?php if($nameError != '') { ?>
				<div class="alertBox red formError">
					<div>
						<p><?php echo $nameError; ?></p>
					</div>
				</div> <!-- /.alertBox --> 
				<?php } ?>
			</fieldset>
				
			<fieldset>
				<label for="email">Email<span class="required">&#42;</span></label>
				<input type="email" name="email" id="email" value="<?php if(isset($_POST['email']))  echo $_POST['email'];?>" class="requiredField email" required/>
				<?php if($emailError != '') { ?>
				<div class="alertBox red formError">
					<div>
						<p><?php echo $emailError; ?></p>
					</div>
				</div> <!-- /.alertBox -->
				<?php } ?>
			</fieldset>
			
			<fieldset>
				<label for="subject">Subject<span class="required">&#42;</span></label>
				<input type="text" name="subject" id="subject" value="<?php if(isset($_POST['subject'])) echo $_POST['subject'];?>" class="requiredField" required/>
				<?php if($contactSubjectError != '') { ?>
				<div class="alertBox red formError">
					<div>
						<p><?php echo $contactSubjectError; ?></p>
					</div>
				</div> <!-- /.alertBox --> 
				<?php } ?>
			</fieldset>
				
			<fieldset>
				<label for="commentsText">Message<span class="required">&#42;</span></label>
				<textarea name="comments" id="commentsText" class="requiredField" required><?php if(isset($_POST['comments'])) { if(function_exists('stripslashes')) { echo stripslashes($_POST['comments']); } else { echo $_POST['comments']; } } ?></textarea>
				<?php if($commentError != '') { ?>
				<div class="alertBox red formError">
					<div>
						<p><?php echo $commentError; ?></p>
					</div>
				</div> <!-- /.alertBox -->
				<?php } ?>
			</fieldset>
			
			<fieldset class="hiddenField">
				<label for="checking" class="screenReader">If you want to submit this form, please do not enter anything in this field:</label><input type="text" name="checking" id="checking" class="screenReader" value="<?php if(isset($_POST['checking']))  echo $_POST['checking'];?>" />
				<input type="hidden" name="submitted" id="submitted" value="true" />
			</fieldset>
			
			<button type="submit" style="clear:both!important; display:block!important;"><div><p>Send</p></div></button>
		</form>
<?php } ?>