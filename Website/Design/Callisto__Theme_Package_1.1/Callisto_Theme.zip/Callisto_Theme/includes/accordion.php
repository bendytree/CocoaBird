<div id="kwicks-wrapper">
	<div class="preload">
		<ul class="kwicks horizontal preloadMe" >
			<?php $args = array(
				'post_type' => array('portfolios', 'post', 'page'),
				'category_name' => get_option('of_featured_category'),
				'posts_per_page' => 5
			);
			$featuredPosts = new WP_Query($args); ?>
			<?php $featuredPosts->query; ?>	        	
			<?php while ($featuredPosts->have_posts()) : $featuredPosts->the_post(); ?>	
			<li>
			
				<article>
					<a href="<?php the_permalink(); ?>">
						<?php echo the_post_thumbnail('slider_image', array( 'title' => '')); ?>
						<?php if (get_option('of_home_slider_caption') == 'true') : ?>
							<div class="kwicksCaption">
								<div class="nivo-caption-shadow"></div>
								<h2 class="kwicksCaptionHeader"><?php echo the_title(); ?></h2>
								<?php echo the_excerpt(); ?>
							</div>
						<?php endif; ?>
					</a>
				</article>
				
			</li>
			<?php endwhile; ?>		        	            
		</ul> <!-- ./kwicks -->
		<script>
			jQuery('.kwicks li:not(li:last-child)').prepend('<span class="kwicksShadow"></span>');
		</script>
	</div> <!-- /.preload -->
	<?php if (get_option('of_home_featured_ribbon') == 'true') echo '<div class="featuredRibbon"></div>'; ?>
	<span class="sliderShadow"></span>	
</div> <!-- /#kwicks-wrapper -->