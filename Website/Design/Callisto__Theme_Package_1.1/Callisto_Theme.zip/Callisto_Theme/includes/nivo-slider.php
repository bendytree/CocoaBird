<div id="slider-wrapper" class="group"> 
	<div class="preload group">
		<div id="slider" class="nivoSlider preloadMe group">
			<?php $args = array(
				'post_type' => array('portfolios', 'post', 'page'),
				'category_name' => get_option('of_featured_category'),
				'posts_per_page' => 5
			);
			$featuredPosts = new WP_Query($args); ?>
			<?php $featuredPosts->query; ?>	
			<?php while ($featuredPosts->have_posts()) : $featuredPosts->the_post(); ?>      	
				<a href="<?php the_permalink(); ?>">
					<?php echo the_post_thumbnail('slider_image', array( 'title' => '#' . get_the_ID())); ?>
				</a>      
        	<?php endwhile; ?>        	            
        </div> <!-- /#slider -->
	    
	    <?php if (get_option('of_home_slider_caption') == 'true') : ?>
			<?php $featuredPosts->query; ?>      	
			<?php while ($featuredPosts->have_posts()) : $featuredPosts->the_post(); ?>
				<article class="nivo-html-caption" id="<?php echo the_ID(); ?>">
					<a href="<?php echo the_permalink(); ?>">
						<h2 class="captionHeader"><?php echo the_title(); ?></h2>
						<?php echo the_excerpt(); ?>
					</a>
				</article>
			<?php endwhile; ?>
		<?php endif; ?>
		
	</div> <!-- /.preload -->
	<?php if (get_option('of_home_featured_ribbon') == 'true') echo '<div class="featuredRibbon"></div>'; ?>
	<span class="sliderShadow"></span>	
</div> <!-- /#slider-wrapper -->

<script>
	jQuery(window).load(function() {
	    jQuery('#slider').nivoSlider({
	    
	    	//Get options for slider from theme options settings
	    	manualAdvance: <?php if (get_option('of_slider_autostart') == 'true') echo 'false'; else echo 'true'; ?>,
	    	animSpeed: <?php echo get_option('of_slider_anim_speed'); ?>,
	    	effect: '<?php echo get_option('of_slider_effect'); ?>',
	    	pauseTime: <?php echo get_option('of_slider_pause_time'); ?>,
	    	startSlide: <?php echo get_option('of_slider_start_slide'); ?>,
	    	customChange: function(){
	    	                <?php if (get_option('of_font_method') == 'cufon' || get_option('of_font_method') == '') echo "Cufon.refresh('.captionHeader');"; ?>
	    	            }, //If Cufon is enabled, refresh caption between slides	
	    	pauseOnHover: true,
	    	captionOpacity: 1,
	    	controlNavThumbs: true,
	    	featuredHeight: <?php echo get_option('of_featured_area_height'); ?>,
	    	controlNavThumbsReplace: '-168x<?php echo round((get_option('of_featured_area_height') / 5.77380952)); ?>.jpg',
	    	afterLoad: function(){
	    		var count = jQuery('.nivo-html-caption').length;
	    		for (var i = 0; i < count; i++) {
	    			var caption = jQuery('h2', '.nivo-html-caption').eq(i).text();
	    			jQuery('.nivo-control').eq(i).attr('title', caption);
	    		}
	    		
	    		jQuery('.nivo-control').hover(function() {
	    			jQuery('img', this).stop().animate({opacity:'.15'},250);
	    			
	    		},function() {
	    			jQuery('img', this).stop().animate({opacity:'1'},250);
	    		});
	    		
	    		jQuery(function(){
	    			jQuery('.nivo-control').tipTip({maxWidth: "auto", delay: 0, fadeIn: 250, fadeOut: 250});
	    		});
	    	}
	    });
	});
</script>