<article id="image-wrapper"> 
	<div class="preload">
		<?php $args = array(
			'post_type' => array('portfolios', 'post', 'page'),
			'category_name' => get_option('of_featured_category'),
			'posts_per_page' => 1
		);
		$featuredPosts = new WP_Query($args); ?>
		<?php $featuredPosts->query; ?>	
		<?php while ($featuredPosts->have_posts()) : $featuredPosts->the_post(); ?>      	
			<a href="<?php the_permalink(); ?>">
				<?php echo the_post_thumbnail('slider_image', array( 'title' => '#' . get_the_ID())); ?>
			</a>
			<div class="nivo-caption image-caption">
				<div class="nivo-caption-shadow"></div>
				<a href="<?php echo the_permalink(); ?>">
					<h2 class="captionHeader"><?php echo the_title(); ?></h2>
					<?php echo the_excerpt(); ?>
				</a>
			</div>
		<?php endwhile; ?>		        	            
	</div> <!-- /.preload -->
	<?php if (get_option('of_home_featured_ribbon') == 'true') echo '<div class="featuredRibbon"></div>'; ?>
	<span class="sliderShadow"></span>	
</article> <!-- /#image-wrapper -->