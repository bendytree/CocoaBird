<?php get_header(); ?>

<section>
	<header class="titleSpace">
		<div class="container group">
			<h1>404</h1>
			<nav class="breadcrumbs">
				<ul>
					<li><a href="<?php bloginfo('url'); ?>"><?php if (get_option('of_trans_breadcrumb_home_link') != '') echo stripslashes(get_option('of_trans_breadcrumb_home_link')); else echo 'Home'; ?></a> &raquo; </li>
					<li>404</li>
				</ul> <!-- /.breadcrumbs -->
			</nav>
		</div> <!-- /.container -->
	</header> <!-- /.titleSpace -->
		
	<div class="container group">
		<div class="containerInner group">
		
			<div class="pageBlock">
				<span class="pageTop"></span>
				<div class="pageMiddle group">
					<h2><?php if (get_option('of_trans_404_title') != '') echo stripslashes(get_option('of_trans_404_title')); else echo 'Page Not Found'; ?></h2>
					<p><?php if (get_option('of_trans_404_text') != '') echo stripslashes(get_option('of_trans_404_text')); else echo 'Sorry, but the page you are looking for could not be found.<br />If this seems to be an error on our part, please consider notifying us to let us know. We appreciate any and all information relating to broken links and other potential errors in site structure.'; ?></p>
				</div> <!-- /.pageMiddle -->
				<span class="pageBottom"></span>
				<span class="pageShadow"></span>
			</div> <!-- /.pageBlock -->
			
		</div> <!-- /.containerInner -->
	</div> <!-- /.container -->
</section>

<?php get_footer(); ?>