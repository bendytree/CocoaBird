<?php get_header(); ?>

<section>
	<header class="titleSpace">
		<div class="container group">
			<h1>Archives for '<?php single_cat_title(); ?>'</h1>
			<?php if (function_exists('breadcrumbs')) breadcrumbs(); ?>
		</div> <!-- /.container -->
	</header> <!-- /.titleSpace -->
	
	<div class="container group">
		<div class="containerInner group">
			<?php if (get_option('of_blog_sidebar') == 'true') echo '<div class="pageHolder group">'; ?>
				<?php if (get_option('of_blog_columns') == 'two' || get_option('of_blog_columns') == 'three') echo '<div class="masonry group">'; ?>
					
					
					<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
				
					<section class="pageBlock group <?php if (get_option('of_blog_columns') == 'one' && get_option('of_blog_sidebar') == 'false') echo ''; elseif (get_option('of_blog_columns') == 'one' && get_option('of_blog_sidebar') == 'true') echo 'boxTwoThirds';  elseif  (get_option('of_blog_columns') == 'two' && get_option('of_blog_sidebar') == 'false') echo 'boxOneHalf';  else  echo 'boxOneThird'; ?>">
						<span class="pageTop"></span>
						<div class="pageMiddle group">
							
							<?php if (get_option('of_blog_columns') == 'one') $thumbSize = 'large'; elseif (get_option('of_blog_columns') == 'two' && get_option('of_blog_sidebar') == 'false') $thumbSize = 'medium'; else $thumbSize = 'small'; ?>
							<?php if (get_option('of_blog_columns') == 'one' && get_option('of_blog_sidebar') == 'false') $largeClass = 'twoThirds first'; ?>
							<?php if ( has_post_thumbnail() ) {
								echo '<a href="';
								echo the_permalink();
								echo '" class="preloadHolder '.$largeClass.'">';
							    the_post_thumbnail('callisto_'.$thumbSize, array('class' => 'postThumb preloadMe'));
							    echo '</a>';
							} ?>
							
							<?php if  (get_option('of_blog_columns') == 'one' && get_option('of_blog_sidebar') == 'false') echo '<div class="portfolioInfo oneThird">';  ?>
								<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<footer class="cal_post_meta group">
									<ul>
										<li class="metaDate"><time datetime="<?php the_time('c'); ?>" pubdate><?php the_time('l, F jS, Y'); ?></time></li>
										<?php
											echo '<li class="metaCat">';
											echo the_category(', ') . '</li>';
										if (has_tag()) {
											echo '<li class="metaTag">';
											echo the_tags('', ', ') . '</li>';
										} if (get_comments_number() != 0) {
											echo '<li class="metaComment"><a href="';
											echo comments_link() . '">';
											printf( _n( '1 Comment', '%1$s Comments', get_comments_number() ), number_format_i18n( get_comments_number() ));
											echo '</a></li>';
										} ?>
									</ul>
								</footer> <!-- /.cal_post_meta -->
								<?php the_excerpt(); ?>
								<a href="<?php the_permalink(); ?>" class="button <?php if  (get_option('of_blog_columns') == 'two' && get_option('of_blog_sidebar') == 'true' || get_option('of_blog_columns') == 'three') echo 'width100';  elseif  (get_option('of_blog_columns') == 'two' && get_option('of_blog_sidebar') == 'false') echo 'right';  ?>">
									<div>
										<p>Read More</p>
									</div>
								</a> <!-- /.button -->
							<?php if  (get_option('of_blog_columns') == 'one' && get_option('of_blog_sidebar') == 'false') echo '</div> <!-- /.portfolioInfo -->';  ?>
						
						</div> <!-- /.pageMiddle -->
						<span class="pageBottom"></span>
						<span class="pageShadow"></span>
					</section> <!-- /.pageBlock -->
					
					<?php endwhile; ?>
				
				<?php if  (get_option('of_blog_columns') == 'two' || get_option('of_blog_columns') == 'three') echo '</div> <!-- /.masonry -->';  ?>
			<?php pagination(); ?>
			<?php if  (get_option('of_blog_sidebar') == 'true') echo '</div> <!-- /.pageHolder -->';  ?>
			<?php if (get_option('of_blog_sidebar') == 'true') get_sidebar(); ?>
			
		</div> <!-- /.containerInner -->
	</div> <!-- /.container -->
</section>

<?php get_footer(); ?>