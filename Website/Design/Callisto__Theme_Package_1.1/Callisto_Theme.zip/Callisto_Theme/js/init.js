/*-----------------------------------------------------------------------------------*/
/* Element Styling */
/*-----------------------------------------------------------------------------------*/

jQuery('.flickr_badge_image img').addClass('preloadMe');

jQuery('.zoomMe').before('<span class="zoom" style="opacity:0"></span>');

jQuery('.playMe').before('<span class="play" style="opacity:0"></span>');


/*-----------------------------------------------------------------------------------*/
/* Content Preloading */
/*-----------------------------------------------------------------------------------*/	                  
	     
jQuery(function() {
	jQuery('.preloadMe, .avatar').hide();
});
	
jQuery(window).bind('load', function() {
		var i = 1;
		var preloads = jQuery('.preloadMe, .avatar').length;
		var int = setInterval(function() {
		if(i >= preloads) clearInterval(int);
		jQuery('.preloadMe:hidden, .avatar:hidden').eq(0).fadeIn(400);
		i++;
	}, 100);		
});

	
/*-----------------------------------------------------------------------------------*/
/* Tabbed Content */
/*-----------------------------------------------------------------------------------*/

jQuery.fn.tabMe = function(){ 
	//Default Action
	jQuery(this).find(".tab_content").hide(); //Hide all content
	jQuery(this).find(".tab_content:first").show(); //Show first tab content
	
	//On Click Event
	jQuery("ul.tabs li").click(function() {
		jQuery(this).parent().parent().find("ul.tabs li").removeClass("active"); //Remove any "active" class
		jQuery(this).addClass("active"); //Add "active" class to selected tab
		jQuery(this).parent().parent().find(".tab_content").hide(); //Hide all tab content
		var activeTab = jQuery(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
		jQuery(activeTab).fadeIn(); //Fade in the active content
		return false;
	});
};

jQuery(".tabbedContent").tabMe(); //Run function


/*-----------------------------------------------------------------------------------*/
/* Toggled Content */
/*-----------------------------------------------------------------------------------*/

//Hide (Collapse) the toggle containers on load
jQuery(".toggle_container").hide(); 

//Switch the "Open" and "Close" state per click then slide up/down (depending on open/close state)
jQuery("h3.trigger").click(function(){
	jQuery(this).toggleClass("active").next().slideToggle(200);
	return false; //Prevent the browser jump to the link anchor
});


/*-----------------------------------------------------------------------------------*/
/* Hover Effects */
/*-----------------------------------------------------------------------------------*/

jQuery('a:has(".postThumb")').hover(function() {
	jQuery('.zoom', this).fadeTo(250, .7);
},function() {
	jQuery('.zoom', this).fadeOut(250);
});

jQuery('a:has(".postThumb")').hover(function() {
	jQuery('.play', this).fadeTo(250, .5);
},function() {
	jQuery('.play', this).fadeOut(250);
});

jQuery('.footer .flickr_badge_image').not(this).hover(function() {
	jQuery('.footer .flickr_badge_image').not(this).stop().animate({opacity:'.6'},250);
},function() {
	jQuery('.footer .flickr_badge_image').not(this).stop().animate({opacity:'1'},250);
});

jQuery('.sidebar .flickr_badge_image').hover(function() {
	jQuery('.sidebar .flickr_badge_image').not(this).stop().animate({opacity:'.7'},250);
},function() {
	jQuery('.sidebar .flickr_badge_image').not(this).stop().animate({opacity:'1'},250);
});

jQuery('.sidebar .advert125').hover(function() {
	jQuery('.sidebar .advert125').not(this).stop().animate({opacity:'.8'},250);
},function() {
	jQuery('.sidebar .advert125').not(this).stop().animate({opacity:'1'},250);
});


/*-----------------------------------------------------------------------------------*/
/* Pre/Code Hover Expansion */
/*-----------------------------------------------------------------------------------*/

jQuery(function() {

	if (jQuery.browser.msie && jQuery.browser.version.substr(0,1)<8) {
		// Do nothing
	} else {
		jQuery('.pageBlock:has(pre)').css('z-index', '999');
		jQuery("pre").wrapInner("<span></span>");
		jQuery("pre").hover(function() {
		    var contentwidth = jQuery(this).contents().width();
		    
		    if(contentwidth > jQuery(this).width()) {
		        jQuery(this).stop().animate({ width: contentwidth }, 150);
		        }
		    }, function() {	        
			    jQuery(this).stop().animate({ width: jQuery(this).parent().width() -16 }, 150);
		});
	}
	
});


/*-----------------------------------------------------------------------------------*/
/* Shadow resizing to fit small screen resolutions */
/*-----------------------------------------------------------------------------------*/

onResize = function() { 
	var winWidth = jQuery(window).width(); 
	if(winWidth <= 1028) {
		jQuery('.pageBlock:not(".boxOneThird", ".boxTwoThirds", ".boxOneHalf") .pageShadow, .sliderShadow').css('width', '1005px');
		jQuery('.pageBlock.boxOneHalf .pageShadow').css('width', '495px');
		jQuery('.pageBlock.boxOneThird .pageShadow').css('width', '331px');
	} else {
		jQuery('.pageBlock:not(".boxOneThird", ".boxTwoThirds", ".boxOneHalf") .pageShadow, .sliderShadow').css('width', '1026px');
		jQuery('.pageBlock.boxOneHalf .pageShadow').css('width', '500px');
		jQuery('.pageBlock.boxOneThird .pageShadow').css('width', '338px');
	}
 }

jQuery(document).ready(onResize);

jQuery(window).bind('resize', onResize);


/*-----------------------------------------------------------------------------------*/
/* CSS Selector Fixes for Old Browsers */
/*-----------------------------------------------------------------------------------*/

jQuery('.pageBlock p:last-child, .pageBlock ul:last-child, .pageBlock ol:last-child, .pageBlock .alertBox:last-child, .pageBlock form:last-child, .pageBlock fieldset:last-child, .pageBlock div:last-child, table:last-child, pre:last-child, .button:last-child, button:last-child, .googleMap:last-child, h1:last-child, h2:last-child, h3:last-child, h4:last-child, h5:last-child, h6:last-child, .wp-caption:last-child, .tabsLeft ul li:last-child, iframe:last-child, blockquote:last-child, .sidebar ul:last-child').css('margin-bottom', '0');
jQuery('.menu > li:last-child a').css('padding-right', '0');
jQuery('.menu > li:has(ul) a strong').css('padding-right', '20px');
jQuery('.menu li:last-child > a .downarrowclass').css('right', '2px');
jQuery('.menu li ul li:last-child > a').css({
	'border-bottom' : '0',
	'padding-bottom' : '10px'
});
jQuery('.sliderHolder:last-child').css('margin-bottom', '19px');
jQuery('.footer ul li:last-child a').css('border-bottom', '0');
jQuery('.sidebar ul li:last-child a').css('border-bottom', '0');
jQuery('.kwicks li:last-child').css('margin-right', '0');
jQuery('.pageBlock li:last-child').css({
	'padding-bottom' : '0',
	'background-position' : '0 70%'
});
jQuery('.tabsTop ul.tabs li:last-child').css('margin-right', '0');
jQuery('.pageDivider:last-child').css('margin-bottom', '5px');
jQuery('.advert125:nth-child(odd)').css('margin-right', '0');
jQuery('.footerOneFourth .flickr_badge_image:nth-child(odd)').css('margin-right', '24px');
jQuery('.footerOneThird .flickr_badge_image:nth-child(3n+2)').css('margin-right', '0');
jQuery('.sidebar .flickr_badge_image:nth-child(3n+2)').css('margin', '0 0 16px -1px');
jQuery('#twitter_update_list li:last-child').css('border-bottom', '0');


/*-----------------------------------------------------------------------------------*/
/* Smooth Scroll to Top */
/*-----------------------------------------------------------------------------------*/

jQuery('a[href=#top]').click(function(){
	jQuery('html, body').stop().animate({scrollTop:0}, 650);
	return false;
});