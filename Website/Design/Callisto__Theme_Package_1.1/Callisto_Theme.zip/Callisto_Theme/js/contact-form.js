jQuery(document).ready(function($) {
	$('form#contactForm').submit(function() {
		$('form#contactForm .alertBox').remove();
		var hasError = false;
		$('.requiredField').each(function() {
			if(jQuery.trim($(this).val()) == '') {
				var labelText = $(this).prev('label').text();
				$(this).parent().append('<div class="alertBox red formError"><div><p>Please enter your '+labelText+'.</p></div></div>');
				hasError = true;
			} else if($(this).hasClass('email')) {
				var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
				if(!emailReg.test(jQuery.trim($(this).val()))) {
					var labelText = $(this).prev('label').text();
					$(this).parent().append('<div class="alertBox red formError"><div><p>You entered an invalid '+labelText+'.</p></div></div>');
					hasError = true;
				}
			}
		});
		if(!hasError) {
			$('form#contactForm li.buttons button').fadeOut('normal', function() {
				$(this).parent().append('<img src="/../img/loading.gif" alt="Loading&hellip;" height="64" width="64" />');
			});
			var formInput = $(this).serialize();
			$.post($(this).attr('action'),formInput, function(data){
				$('form#contactForm').slideUp("fast", function() {				   
					$(this).before('<div class="alertBox green formSuccess"><div><p>Your message was successfully sent.</p></div></div>');
				});
			});
		}
		return false;	
	});
});