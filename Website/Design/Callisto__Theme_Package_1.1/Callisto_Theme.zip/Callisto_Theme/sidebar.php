<aside role="complementary" class="sidebar pageBlock boxOneThird">
	<span class="pageTop"></span>
		<div class="pageMiddle group">
			
			<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('sidebar-widgetized-area')) : else : ?>
			<?php endif; ?>

		</div> <!-- /.pageMiddle -->
	<span class="pageBottom"></span>
	<span class="pageShadow"></span>
</aside> <!-- /.pageBlock -->