<?php
/*
Template Name: Blank Template
*/
get_header(); ?>

<section>
	<header class="titleSpace">
		<div class="container group">
			<h1><?php the_title(); ?></h1>
			<?php if (function_exists('breadcrumbs')) breadcrumbs(); ?>
		</div> <!-- /.container -->
	</header> <!-- /.titleSpace -->
		
	<div class="container group">
		<div class="containerInner group">
		
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
				<?php the_content(); ?>
			<?php endwhile; ?>
			
		</div> <!-- /.containerInner -->
	</div> <!-- /.container -->
</section>

<?php get_footer(); ?>