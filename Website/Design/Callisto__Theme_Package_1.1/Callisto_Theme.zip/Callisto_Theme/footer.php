<aside class="footer" role="complementary">
	<div class="lightOverlay">
		<div class="footerInner">
			<div class="container group">
				<div class="containerInner group">
					<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('footer-widgetized-area')) : else : ?>
					<?php endif; ?>
				</div> <!-- /.containerInner -->
			</div> <!-- /.container -->
		
			<footer class="footerLower">
				<div class="container group">
					<p><?php if (get_option('of_trans_footer_copy') != '') echo stripslashes(get_option('of_trans_footer_copy')); else echo 'Copyright &copy; '; ?>
					
					<?php echo date('Y'); ?> <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>. <?php if (get_option('of_trans_footer_text') != '') echo stripslashes(get_option('of_trans_footer_text')); else echo 'All Rights Reserved.'; ?></p>
				
					<a href="<?php bloginfo('url'); ?>" class="logoFooter">
						<img src="<?php echo get_option('of_footer_logo'); ?>" alt="Home" title="Home" />
					</a> <!-- /.logoFooter -->
					
				</div> <!-- /.container -->
			</footer> <!-- /.footerLower -->
		</div> <!-- /.footerInner -->
	</div> <!-- /.lightOverlay -->
</aside> <!-- /.footer -->
<?php wp_footer(); ?>
<?php if ( strpos($post->post_content, 'slider') !== false || strpos(get_option('sidebars_widgets'), 'slider') !== false) { ?>
	<script>
		jQuery(window).load(function() {
		    jQuery('.sliderEmbed').nivoSlider({
		    	manualAdvance: <?php if (get_option('of_slider_autostart') == 'true') echo 'false'; else echo 'true'; ?>,
		    	animSpeed: <?php echo get_option('of_slider_anim_speed'); ?>,
		    	effect: '<?php echo get_option('of_slider_effect'); ?>',
		    	pauseTime: <?php echo get_option('of_slider_pause_time'); ?>,
		    	startSlide: <?php echo get_option('of_slider_start_slide'); ?>,
		    	
		    	pauseOnHover: true,
		    	captionOpacity: 1
		    });
		});
	</script>
<?php } ?>
<?php if (get_option('of_font_method') == 'cufon' || get_option('of_font_method') == '') echo '<script>Cufon.now()</script>'; ?>
</body>
</html>